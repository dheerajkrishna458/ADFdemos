"""Data Quality module for medallion framework"""
