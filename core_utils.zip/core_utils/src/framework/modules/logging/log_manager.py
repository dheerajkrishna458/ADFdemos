"""Centralized logging for Databricks: buffers logs in-memory, persists to Delta, graceful shutdown."""

import atexit
import sys
import logging
import json
import signal
from datetime import datetime
from typing import Any
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType
from framework.modules.io.writer import DeltaManager

LOG_FORMAT = "%(asctime)s - [%(levelname)s] - %(name)s:%(funcName)s() - %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


# ============================================================================
# CUSTOM FORMATTER
# ============================================================================

class CustomFormatter(logging.Formatter):
    """Shortens long module paths: 'framework.modules.io.writer' → 'f.m.i.writer'."""

    def format(self, record):
        original_name = record.name
        parts = original_name.split(".")
        if len(parts) > 3:
            abbreviated = ".".join(p[0] for p in parts[:-2])
            record.name = f"{abbreviated}.{parts[-2]}.{parts[-1]}"
        try:
            return super().format(record)
        finally:
            record.name = original_name


# ============================================================================
# CANCELLATION EXCEPTION
# ============================================================================

class UserCancelledException(BaseException):
    """Raised on job cancellation (Ctrl+C, timeout). Extends BaseException to bypass except blocks."""


# ============================================================================
# RUNTIME MANAGER - Shutdown Coordination
# ============================================================================

class RuntimeManager:
    """Registers shutdown hooks to flush logs on job termination (atexit, SIGINT, SIGTERM)."""

    _hooks_installed = False
    _buffer_handlers = set()  # Track handlers to flush
    _termination_signal_received = False

    @classmethod
    def flush_logs_on_shutdown(cls) -> None:
        """Flush all registered buffer handlers."""
        for handler in list(cls._buffer_handlers):
            try:
                handler.flush()
            except Exception:
                logger = logging.getLogger(__name__)
                logger.exception("Failed to flush handler during shutdown.")

    @classmethod
    def flush_logs_on_shutdown_once(cls, handler: "BufferingHandler") -> None:
        """Register a buffer handler for shutdown flush."""
        cls._buffer_handlers.add(handler)

    @classmethod
    def unregister_buffer_handler(cls, handler: "BufferingHandler") -> None:
        """Remove a buffer handler from shutdown tracking."""
        cls._buffer_handlers.discard(handler)

    @classmethod
    def handle_termination_signal(cls, signum, _frame) -> None:
        """Signal handler for SIGINT/SIGTERM. Raises UserCancelledException; flush happens in run_layer finally.
        
        Args:
            signum: Signal number (e.g., signal.SIGINT, signal.SIGTERM).
            _frame: Current stack frame when signal was received. REQUIRED by Python's signal.signal() API.
                    DO NOT REMOVE - if omitted, raises TypeError when OS sends signal because Python 
                    automatically passes 2 arguments (signum, frame) and handler signature must match.
                    Prefixed with underscore because it's not used in this implementation.
        """
        if cls._termination_signal_received:
            raise UserCancelledException(f"Interrupted by signal {signum}")

        cls._termination_signal_received = True
        logger = logging.getLogger(__name__)
        logger.warning("Signal %s received. Cancellation requested.", signum)
        raise UserCancelledException(f"Interrupted by signal {signum}")

    @classmethod
    def reset_termination_state(cls) -> None:
        """Reset cancellation signal state for next run in long-lived sessions."""
        cls._termination_signal_received = False

    @classmethod
    def _is_job_compute(cls, job_id, run_id) -> bool:
        """Return True only when both job_id and run_id are numeric strings.

        On job clusters both values are always integer IDs assigned by Databricks.
        On all-purpose interactive clusters they are absent or non-numeric, so
        overriding SIGINT/SIGTERM is unsafe (it disrupts the shared IPyKernel).
        """
        try:
            return bool(job_id and run_id and int(job_id) and int(run_id))
        except (TypeError, ValueError):
            return False

    @classmethod
    def install_signal_handlers_if_job_compute(cls, job_id, run_id) -> None:
        """Install SIGINT/SIGTERM handlers only when running on a job cluster."""
        if cls._is_job_compute(job_id, run_id):
            signal.signal(signal.SIGINT, cls.handle_termination_signal)
            if hasattr(signal, "SIGTERM"):
                signal.signal(signal.SIGTERM, cls.handle_termination_signal)

    @classmethod
    def enable_graceful_shutdown(cls) -> None:
        """Register atexit flush handler. Idempotent.

        Signal handlers are NOT installed here because args are not yet parsed.
        Call install_signal_handlers_if_job_compute() once job_id/run_id are known.
        """
        if cls._hooks_installed:
            return
        atexit.register(cls.flush_logs_on_shutdown)
        cls._hooks_installed = True


# ============================================================================
# LOGGING CONFIGURATOR - Setup & Delta Infrastructure
# ============================================================================

class LoggingConfigurator:
    """Manages console + buffering. Delta write deferred until flush time."""

    @classmethod
    def _ensure_custom_console_formatter(cls, root: logging.Logger, level: int) -> None:
        """Apply custom formatter to all existing stream handlers on root logger."""
        stream_handlers = [h for h in root.handlers if isinstance(h, logging.StreamHandler)]
        if not stream_handlers:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(level)
            console_handler.setFormatter(CustomFormatter(fmt=LOG_FORMAT, datefmt=DATE_FORMAT))
            root.addHandler(console_handler)
            return

        for handler in stream_handlers:
            handler.setLevel(level)
            handler.setFormatter(CustomFormatter(fmt=LOG_FORMAT, datefmt=DATE_FORMAT))

    @classmethod
    def get_or_create_buffer_handler(cls, level: int = logging.INFO) -> "BufferingHandler":
        """Get existing or create new BufferingHandler on root logger."""
        root = logging.getLogger()
        cls._ensure_custom_console_formatter(root, level)
        
        # Check if BufferingHandler already attached
        for handler in root.handlers:
            if isinstance(handler, BufferingHandler):
                return handler
        
        # Create and attach new BufferingHandler
        buffer_handler = BufferingHandler(level=level)
        root.addHandler(buffer_handler)
        root.setLevel(level)
        return buffer_handler

    @classmethod
    def configure_console(cls, level: int = logging.INFO) -> logging.Logger:
        """Configure root logger with console + buffering handlers."""
        return cls.get_or_create_buffer_handler(level).root_logger

    @classmethod
    def setup_for_run(
        cls,
        env_manager,
        delta_manager: DeltaManager,
        level: int = logging.INFO,
    ) -> "BufferingHandler":
        """Main entrypoint for logging setup during a pipeline run.

        Flow:
        1) Ensure console + buffer handlers exist on root logger.
        2) Attach Delta/run context needed for flush.
        3) Return handler so callers can optionally enrich context later.
        
        To set yaml_load_history_id later, use handler.set_context().
        """
        # Step 1: Ensure the root logger is configured and a buffer handler exists.
        handler = cls.get_or_create_buffer_handler(level)

        # Step 2: Bind runtime context and Delta target details.
        handler.set_delta_context(
            delta_manager=delta_manager,
            env_manager=env_manager,
        )

        # Step 3: Expose handler for optional follow-up context updates.
        return handler

    @classmethod
    def configure_delta_context(
        cls,
        env_manager,
        delta_manager: DeltaManager,
    ) -> None:
        """Backward-compatible wrapper around setup_for_run()."""
        cls.setup_for_run(
            env_manager=env_manager,
            delta_manager=delta_manager,
        )

    @classmethod
    def flush_and_detach_buffer_handlers(cls, logger: logging.Logger | None = None) -> None:
        """Flush buffered logs once, then unregister and detach handlers."""
        root = logging.getLogger()
        for handler in root.handlers[:]:
            if isinstance(handler, BufferingHandler):
                try:
                    handler.flush()
                except Exception:
                    if logger:
                        logger.exception("Failed to flush logs")
                finally:
                    RuntimeManager.unregister_buffer_handler(handler)
                    root.removeHandler(handler)
                    try:
                        handler.close()
                    except Exception:
                        pass


# ============================================================================
# BUFFERING HANDLER - In-Memory Buffer (No Delta deps)
# ============================================================================

class BufferingHandler(logging.Handler):
    """Buffers log records in-memory. Delta context set later for flush."""

    def __init__(self, level=logging.INFO):
        super().__init__(level)
        self.root_logger = logging.getLogger()
        self._events: list[str] = []  # Buffer: list of formatted log messages
        self._is_flushing = False
        self._formatter = CustomFormatter(fmt=LOG_FORMAT, datefmt=DATE_FORMAT)
        self.setFormatter(self._formatter)
        
        # Delta context (set later via set_delta_context)
        self.spark = None
        self.table_name = None
        self.delta_manager = None
        
        # Run context
        self._context = {
            "workspace_name": None,
            "layer": None,
            "args": None,
            "yaml_load_history_id": None,
            "databricks_run_id": None,
            "databricks_job_id": None,
            "correlation_id": None,
        }
        
        # Schema for Delta table rows
        self.schema = StructType([
            StructField("workspace_name", StringType(), True),
            StructField("layer", StringType(), True),
            StructField("args", StringType(), True),
            StructField("code_message", StringType(), False),
            StructField("yaml_load_history_id", StringType(), True),
            StructField("databricks_job_id", StringType(), True),
            StructField("databricks_run_id", StringType(), True),
            StructField("correlation_id", StringType(), True),
            StructField("created_dtm", TimestampType(), False),
        ])
        
        # Internal class logger (non-propagating to avoid recursion into buffer)
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self.logger.propagate = False
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(CustomFormatter(fmt=LOG_FORMAT, datefmt=DATE_FORMAT))
            self.logger.addHandler(handler)

    def set_delta_context(
        self,
        delta_manager: DeltaManager,
        env_manager,
    ) -> None:
        """Store Delta context for later flush. Called from layer init."""
        self.spark = env_manager.spark
        self.delta_manager = delta_manager
        self.table_name = env_manager.get_code_log_table_fqn()
        
        # Update context from env_manager
        self._context["workspace_name"] = env_manager.workspace_name
        self._context["args"] = self._build_args_payload(env_manager.args)
        
        args = env_manager.args
        if args is not None:
            databricks_run_id = getattr(args, "databricks_run_id", None)
            databricks_job_id = getattr(args, "databricks_job_id", None)
            correlation_id = getattr(args, "correlation_id", None)
            layer = getattr(args, "layer", None)

            if databricks_run_id is not None:
                self._context["databricks_run_id"] = databricks_run_id
            if databricks_job_id is not None:
                self._context["databricks_job_id"] = databricks_job_id
            if correlation_id is not None:
                self._context["correlation_id"] = correlation_id
            if layer is not None:
                self._context["layer"] = layer

            # Install signal handlers now that we know job_id/run_id.
            # Only activates on job clusters (both values are numeric).
            RuntimeManager.install_signal_handlers_if_job_compute(
                job_id=databricks_job_id,
                run_id=databricks_run_id,
            )

        self.logger.info("Delta context configured for code logs table: %s", self.table_name)
        self._ensure_table_exists()
        RuntimeManager.flush_logs_on_shutdown_once(self)  # Register for graceful shutdown

    def _build_args_payload(self, args) -> str:
        """Convert args object to JSON string for VARIANT."""
        if args is None:
            return None
        return json.dumps(vars(args), default=str, sort_keys=True)

    def _ensure_table_exists(self) -> None:
        """Create Delta table if missing."""
        if not self.spark or not self.table_name:
            return
        create_sql = f"""
        CREATE TABLE IF NOT EXISTS {self.table_name} (
            workspace_name STRING COMMENT 'Databricks workspace name where job ran',
            layer STRING COMMENT 'Medallion layer: Bronze, Silver, or Gold',
            args VARIANT COMMENT 'Job ArgsParser arguments',
            code_message STRING COMMENT 'Aggregated log messages for this flush event',
            yaml_load_history_id STRING COMMENT 'Reference to YAML load history record',
            databricks_job_id STRING COMMENT 'Databricks job identifier',
            databricks_run_id STRING NOT NULL COMMENT 'Unique databricks run identifier for this job execution',
            correlation_id STRING COMMENT 'Correlation ID for tracing related log messages across runs',
            created_dtm TIMESTAMP NOT NULL COMMENT 'UTC timestamp when logs were flushed to Delta'
        )
        USING DELTA
        """
        try:
            self.spark.sql(create_sql)
        except Exception:
            pass  # Table may already exist or creation failed; defer to flush

    def emit(self, record: logging.LogRecord):
        """Buffer each log record."""
        # Avoid recursive capture of logs emitted by Delta write path during flush.
        if self._is_flushing:
            return
        self._events.append(self._formatter.format(record))

    def set_context(self, **context: Any) -> None:
        """Update run context (layer, job_id, etc)."""
        for key, value in context.items():
            if key in self._context:
                self._context[key] = value

    def flush(self) -> None:
        """Write buffered logs to Delta table."""
        # Guard against incomplete setup or empty buffer: skip flush if not ready
        if not self._events or not self.spark or not self.table_name:
            return

        # Set flushing flag to prevent recursion: logs emitted by Delta write path
        # are not captured into the buffer (prevents infinite loop)
        self._is_flushing = True
        log_line_count = len(self._events)
        # Combine all buffered log lines into a single multi-line string for code_message column
        combined_message = "\n".join(self._events)
        
        # Build Delta table row: context fields + combined log message + timestamp
        row = (
            self._context["workspace_name"],
            self._context["layer"],
            self._context["args"],
            combined_message,
            self._context["yaml_load_history_id"],
            self._context["databricks_job_id"],
            self._context["databricks_run_id"],
            self._context["correlation_id"],
            datetime.utcnow(),
        )
        
        try:
            # Create DataFrame from single row using predefined schema
            df = self.spark.createDataFrame([row], schema=self.schema)
            # Parse args JSON string into VARIANT type for nested column support
            df = df.withColumn("args", F.parse_json(F.col("args")))
            self.logger.info("Writing DataFrame to table %s", self.table_name)
            # Append logs to Delta table (mode='append' ensures all runs are captured)
            self.delta_manager.write_df(df=df, target_table=self.table_name, mode="append")
            self.logger.info(
                "Flushed %d log lines to %s",
                log_line_count,
                self.table_name,
            )
            # Clear buffer ONLY after successful write to prevent log loss on failure
            self._events.clear()
        except Exception:
            self.logger.exception(
                "Failed to flush logs to Delta table %s",
                self.table_name,
            )
        finally:
            # Always reset flushing flag so future logs can be captured
            self._is_flushing = False

    def close(self) -> None:
        """Flush and close."""
        try:
            self.flush()
        except Exception:
            pass
        super().close()

