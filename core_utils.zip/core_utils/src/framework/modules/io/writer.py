import time
import random
import logging
from pyspark.sql import DataFrame
from delta.tables import DeltaTable

class DeltaManager:
    """
    Utility class for managing Delta tables in Databricks.
    Provides methods for checking table existence, setting table properties,
    performing robust Delta MERGE operations, and writing DataFrames to Delta tables.
    """

    def __init__(self, spark, args):
        """
        Initialize DeltaManager with Spark session and arguments.

        Args:
            spark (SparkSession): The Spark session.
            args (dict): Additional arguments for configuration.
        """
        self.spark = spark
        self.args = args
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self.default_tbl_properties = {
            "delta.appendOnly": "false",
            "delta.autoOptimize.optimizeWrite": "true",
            "delta.autoOptimize.autoCompact": "true",
            "delta.enableChangeDataFeed": "true",
            "delta.minReaderVersion": "3",
            "delta.minWriterVersion": "7",
            "delta.isolationLevel": "WriteSerializable",
        }

        self.bronze_tbl_properties = {
            "delta.enableRowTracking": "true"
        }
        self.silver_tbl_properties = {}
        self.gold_tbl_properties = {}

    def table_exists(self, table_fqn: str) -> bool:
        """
        Checks if a table exists in the Spark catalog.

        Args:
            table_fqn (str): Fully qualified table name.

        Returns:
            bool: True if table exists, False otherwise.
        """
        return self.spark.catalog.tableExists(table_fqn)

    def get_table_properties(self, table_fqn: str) -> dict:
        """
        Retrieves table properties for a Delta table.

        Args:
            table_fqn (str): Fully qualified table name.

        Returns:
            dict: Table properties as key-value pairs.
        """
        try:
            df = self.spark.sql(f"SHOW TBLPROPERTIES {table_fqn}")
            return {row.key.strip(): row.value.strip() for row in df.collect()}
        except Exception as e:
            raise Exception(f"Failed to get properties for {table_fqn}: {e}")

    def set_table_properties(
        self,
        table_fqn: str,
        extra_properties: dict = None
    ):
        """
        Sets Delta table properties using DEFAULT, BRONZE, SILVER, GOLD.

        Args:
            table_fqn (str): Fully qualified table name.
            extra_properties (dict, optional): Additional properties to set.
        """
        if not self.table_exists(table_fqn):
            raise Exception(f"Table {table_fqn} does not exist; cannot set properties.")

        # Merge default properties with any overrides
        required_properties = {
            **self.default_tbl_properties,
            **(extra_properties or {})
        }

        existing = self.get_table_properties(table_fqn)

        # Enable auto clustering if not already enabled
        if "clusterByAuto" not in existing:
            self.spark.sql(f"ALTER TABLE {table_fqn} CLUSTER BY AUTO")
            self.logger.info(f"Auto Liquid Clustering Enabled for {table_fqn}")

        # Find properties that need updating
        to_update = {}
        for k, v in required_properties.items():
            current = existing.get(k)
            if str(current).strip().lower().strip('"').strip("'") != str(v).strip().lower().strip('"').strip("'"):
                to_update[k] = v

        if not to_update:
            return

        set_clause = ", ".join([f"'{k}' = '{v}'" for k, v in to_update.items()])
        self.spark.sql(f"ALTER TABLE {table_fqn} SET TBLPROPERTIES ({set_clause})")

        self.logger.info(f"Updated table properties on {table_fqn}.")


    def merge_df(
        self,
        source_df: DataFrame,
        target_table: str,
        merge_condition: str,
        update_dict: dict | None = None,
        insert_dict: dict | None = None,
        update_condition: str | None = None,
        update_all: bool = False,
        insert_all: bool = False,
        table_properties: dict | None = None,
        max_retries: int = 10,
        min_delay: float = 5.0,
        max_delay: float = 60.0
    ):
        """
        Performs a robust MERGE operation on a Delta table with retries for concurrency conflicts.

        Args:
            source_df (DataFrame): Source DataFrame (aliased as 'src').
            target_table (str): Target Delta table FQN (aliased as 'tgt').
            merge_condition (str): SQL condition for matching (e.g., 'tgt.id = src.id').
            update_dict (dict, optional): Column mappings for UPDATE on matched rows.
            insert_dict (dict, optional): Column mappings for INSERT on unmatched rows.
            update_condition (str, optional): Additional condition for WHEN MATCHED updates.
            update_all (bool, optional): Explicitly enables UPDATE ALL behavior.
            insert_all (bool, optional): Explicitly enables INSERT ALL behavior.
            table_properties (dict, optional): Table properties to set after merge.
            max_retries (int, optional): Maximum number of retries for concurrency conflicts.
            min_delay (float, optional): Minimum delay between retries (seconds).
            max_delay (float, optional): Maximum delay between retries (seconds).
        """
        # -------- Validation / Guardrails -------- #
        if update_all and update_dict is not None:
            raise ValueError("Cannot specify both update_all=True and update_dict")

        if insert_all and insert_dict is not None:
            raise ValueError("Cannot specify both insert_all=True and insert_dict")

        if update_condition and not (update_dict or update_all):
            raise ValueError("update_condition requires update_dict or update_all=True")

        # Skip merge if source DataFrame is empty
        if source_df.isEmpty():
            self.logger.info(f"merge: Source DF is empty, skipping merge for {target_table}.")
            return

        # -------- Attempt MERGE with retries -------- #
        for attempt in range(1, max_retries + 1):
            try:
                retry_msg = f"Retry attempt ({attempt}/{max_retries}): " if attempt > 1 else ""

                target = DeltaTable.forName(self.spark, target_table)

                merge_builder = (
                    target.alias("tgt")
                    .merge(source_df.alias("src"), merge_condition)
                )

                # UPDATE logic for matched rows
                if update_all:
                    # Explicit full-row update
                    if update_condition:
                        merge_builder = merge_builder.whenMatchedUpdateAll(
                            condition=update_condition
                        )
                    else:
                        merge_builder = merge_builder.whenMatchedUpdateAll()

                elif update_dict is not None:
                    # Partial update using column mapping
                    if update_condition:
                        merge_builder = merge_builder.whenMatchedUpdate(
                            condition=update_condition,
                            set=update_dict
                        )
                    else:
                        merge_builder = merge_builder.whenMatchedUpdate(
                            set=update_dict
                        )

                # -------- INSERT logic for unmatched rows -------- #
                if insert_all:
                    # Explicit full-row insert
                    merge_builder = merge_builder.whenNotMatchedInsertAll()

                elif insert_dict is not None:
                    # Partial insert using column mapping
                    merge_builder = merge_builder.whenNotMatchedInsert(
                        values=insert_dict
                    )

                # -------- Execute merge -------- #
                self.logger.info(f"{retry_msg}Executing MERGE on {target_table}...")
                merge_builder.execute()
                self.logger.info(f"{retry_msg}MERGE on {target_table} completed.")

                # -------- Apply table properties -------- #
                self.set_table_properties(target_table, extra_properties=table_properties)

                return

            except Exception as e:
                error_msg = str(e)

                # Detect Delta concurrency conflicts
                is_conflict = ("ConcurrentAppendException" in error_msg or "ConcurrentMergeOperation" in error_msg)

                if is_conflict and attempt < max_retries:
                    delay_seconds = random.uniform(min_delay, max_delay)

                    self.logger.warning(f"Concurrency conflict detected on {target_table}: {error_msg}")
                    self.logger.info(
                        f"Retrying merge in {delay_seconds:.2f}s "
                        f"(next attempt {attempt + 1}/{max_retries})..."
                    )

                    time.sleep(delay_seconds)
                    continue

                # Fail hard after exhausting retries
                self.logger.error(f"Failed to MERGE into {target_table} after {attempt} attempt(s): {error_msg}")
                raise

    def write_df(
        self,
        df,
        target_table: str,
        mode: str = "append",
        table_properties: dict[str, str] | None = None,
        max_retries: int = 3,
        max_backoff_secs: int = 20,
    ):
        """
        Writes a DataFrame to a Delta table with safe retry handling for
        Delta Lake concurrency and protocol change conflicts.

        Args:
            df: Spark DataFrame to be written.
            target_table (str): Fully qualified Delta table name.
            mode (str, optional): Write mode (default: "append").
            table_properties (dict[str, str] | None, optional): Table properties
                to set after a successful write.
            max_retries (int, optional): Maximum number of write attempts.
            max_backoff_secs (int, optional): Maximum random backoff time
                in seconds between retries.

        Raises:
            Exception: Propagates non-retryable errors or retry exhaustion.
        """

        retryable_errors = (
            "DELTA_PROTOCOL_CHANGED",
            "Concurrent",
            "MetadataChangedException",
        )

        for attempt in range(1, max_retries + 1):
            try:
                (
                    df.write.format("delta")
                    .mode(mode)
                    .option("mergeSchema", "true")
                    .saveAsTable(target_table)
                )

                if table_properties:
                    self.set_table_properties(
                        target_table, extra_properties=table_properties
                    )

                return  # success

            except Exception as e:
                msg = str(e)

                # Fail fast on non-retryable errors or retry exhaustion
                if attempt == max_retries or not any(err in msg for err in retryable_errors):
                    raise

                # Randomized backoff to reduce writer collision
                delay_seconds = random.uniform(0, max_backoff_secs)
                self.logger.warning("Write conflict detected on %s: %s", target_table, msg)
                self.logger.info(
                        f"Retrying write operation in {delay_seconds:.2f}s "
                        f"(next attempt {attempt + 1}/{max_retries})..."
                    )
                time.sleep(delay_seconds)
