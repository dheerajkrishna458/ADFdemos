# framework/utils/handle_dry_run

import logging
from .plan import build_execution_plan, print_plan
from framework.core.config import ConfigManager

logger = logging.getLogger(f"{__name__}")

def handle_dry_run(args) -> None:
    """
    Dry-run path: validate config, build execution plan, print, and exit.

    This follows the **same pipeline path** as a real run up to the
    point of side effects:
        1. Load + validate YAML
        2. Build RuntimeContext
        3. IngestionFactory.create (spark=None → validates routing only)
        4. Build execution plan
        5. Print plan
        6. Return (no Spark, no reads, no writes)
    """
    # 1. Load & validate YAML
    config_manager = ConfigManager(args)
    config_manager.load_config()
    raw = config_manager.config

    # 4. Build execution plan
    plan = build_execution_plan(raw)

    # 5. Print plan
    print_plan(plan)

    pipeline_name = raw.get("pipeline_metadata", {}).get("name", "unknown")
    logger.info("Dry-run completed for pipeline '%s'.", pipeline_name)