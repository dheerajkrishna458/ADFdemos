"""Audit utilities for tracking pipeline execution and errors"""
