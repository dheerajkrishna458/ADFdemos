import logging
import json
from datetime import datetime

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, VariantType, TimestampType

from framework.core.environment import EnvironmentManager
from framework.core.config import ConfigManager
from framework.modules.io.writer import DeltaManager
from framework.modules.transformations.data import DataTransformations


class YamlTelemetryLogger:
    """
    Logger responsible for preparing and persisting YAML telemetry
    records into the yaml_load_history Delta table.

    Purpose:
    - Audit
    - Observability
    - Lineage / traceability
    """

    @staticmethod
    def yaml_load_history_schema() -> StructType:
        """Explicit schema for yaml_load_history."""
        return StructType([
            StructField("yaml_load_history_id", StringType(), False, {"comment": "UUID row identifier"}),
            StructField("yaml_file_path", StringType(), False, {"comment": "Path to the YAML file"}),
            StructField("yaml_hash", StringType(), False, {"comment": "Hash of YAML contents"}),
            StructField("workspace_name", StringType(), False, {"comment": "Databricks workspace identifier"}),
            StructField("pipeline_name", StringType(), False, {"comment": "Name of the pipeline"}),
            StructField("pipeline_layer", StringType(), False, {"comment": "Pipeline layer"}),
            StructField("yaml_contents", VariantType(), False, {"comment": "Parsed YAML contents"}),
            StructField("effective_datetime", TimestampType(), False, {"comment": "Timestamp when YAML is effective from"}),
            StructField("databricks_run_id", StringType(), True, {"comment": "Databricks run identifier"}),
            StructField("databricks_job_id", StringType(), True, {"comment": "Databricks job identifier"}),
        ])

    def __init__(
        self,
        spark,
        env_manager: EnvironmentManager,
        delta_manager: DeltaManager,
        config_manager: ConfigManager,
    ):
        # Initialize logger and dependencies
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self.spark = spark
        self.env_manager = env_manager
        self.args = env_manager.args
        self.delta_manager = delta_manager
        self.config = config_manager.config
        self.config_file_path = config_manager.config_file_path
        self.yaml_load_history_fqn = self.env_manager.get_yaml_load_history_fqn()
        self.target_schema = self.yaml_load_history_schema()
        self.latest_yaml_load_history_id = None

    # ------------------------------------------------------------------ #
    # Table Management
    # ------------------------------------------------------------------ #

    def create_yaml_load_history_table(self, table_name: str) -> None:
        """Create yaml_load_history Delta table if it does not exist."""
        query = f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            yaml_load_history_id STRING NOT NULL COMMENT 'UUID row identifier',
            yaml_file_path STRING NOT NULL COMMENT 'Path to the YAML file',
            yaml_hash STRING NOT NULL COMMENT 'Hash of YAML contents',
            workspace_name STRING NOT NULL COMMENT 'Databricks workspace identifier',
            pipeline_name STRING NOT NULL COMMENT 'Name of the pipeline',
            pipeline_layer STRING NOT NULL COMMENT 'Pipeline layer',
            yaml_contents VARIANT NOT NULL COMMENT 'Parsed YAML contents',
            effective_datetime TIMESTAMP NOT NULL COMMENT 'Timestamp when YAML is effective from',
            databricks_run_id STRING COMMENT 'Databricks run identifier',
            databricks_job_id STRING COMMENT 'Databricks job identifier'
        )
        USING DELTA
        """
        self.spark.sql(query)

    # ------------------------------------------------------------------ #
    # Validation
    # ------------------------------------------------------------------ #

    def check_duplicate_yaml_hash(self, yaml_hash: str) -> None:
        """Ensures the same yaml_hash is not present across different configs"""

        query = f"""
            SELECT yaml_file_path
            FROM {self.yaml_load_history_fqn}
            WHERE yaml_hash = '{yaml_hash}'
              AND yaml_file_path != '{self.config_file_path}'
        """
        df = self.spark.sql(query)

        if df.isEmpty():
            return

        duplicate_paths = [row.yaml_file_path for row in df.collect()]
        raise ValueError(
            "Duplicate yaml_hash detected across yaml_file_path: "
            f"{duplicate_paths}"
        )

    # ------------------------------------------------------------------ #
    # Data Preparation
    # ------------------------------------------------------------------ #

    def _prepare_source_df(self) -> DataFrame:
        """Prepare the single-row telemetry source DataFrame."""
        records = [{
            "yaml_file_path": self.config_file_path,
            "workspace_name": self.env_manager.workspace_name,
            "pipeline_name": self.config.get("pipeline", {}).get("name"),
            "pipeline_layer": self.args.layer,
            "effective_datetime": datetime.now(),
            "databricks_run_id": self.args.databricks_run_id,
            "databricks_job_id": self.args.databricks_job_id,
        }]

        df = self.spark.createDataFrame(records)

        # Add parsed YAML contents and hash column
        df = df.withColumn("yaml_contents", F.parse_json(F.lit(json.dumps(self.config))))
        df = DataTransformations.add_row_hash(df=df, columns_included=["yaml_contents"], hash_column_name="yaml_hash")
        df = df.withColumn("yaml_load_history_id", F.expr("uuid()"))

        return df.select([field.name for field in self.target_schema.fields])

    # ------------------------------------------------------------------ #
    # Insert Decision Logic
    # ------------------------------------------------------------------ #
    def _should_insert(self, incoming_hash: str):
        """
        Insert if incoming_hash differs from the latest yaml_hash
        for the same yaml_file_path.
        Returns (should_insert: bool, latest_row: Row or None)
        """
        latest_df = (
            self.spark.table(self.yaml_load_history_fqn)
            .filter(F.col("yaml_file_path") == self.config_file_path)
            .orderBy(F.col("effective_datetime").desc())
            .limit(1)
        )

        # No history yet → insert
        if latest_df.isEmpty():
            return True, None
        latest_row = latest_df.first()

        should_insert = incoming_hash != latest_row["yaml_hash"]
        return should_insert, latest_row

    def _get_latest_yaml_load_history_id(self) -> str | None:
        """Returns latest yaml_load_history_id for current yaml_file_path."""
        latest_df = (
            self.spark.table(self.yaml_load_history_fqn)
            .filter(F.col("yaml_file_path") == self.config_file_path)
            .orderBy(F.col("effective_datetime").desc())
            .limit(1)
        )
        if latest_df.isEmpty():
            return None
        latest_row = latest_df.first()
        return latest_row["yaml_load_history_id"]

    # ------------------------------------------------------------------ #
    # Public Entry Point
    # ------------------------------------------------------------------ #

    def log_yaml_load_history(self) -> str | None:
        """
        Insert YAML telemetry only if the incoming yaml_hash
        differs from the latest stored hash for the yaml_file_path.
        """
        self.logger.info(f"Logging YAML telemetry to {self.yaml_load_history_fqn}")

        # Ensure target table exists
        self.create_yaml_load_history_table(self.yaml_load_history_fqn)

        # Prepare source DataFrame for insertion
        src_df = self._prepare_source_df()
        incoming_hash = src_df.select("yaml_hash").first()["yaml_hash"]

        # Validate for duplicate hashes across different record
        self.check_duplicate_yaml_hash(incoming_hash)

        # Skip insert if hash matches latest record
        should_insert, latest_row = self._should_insert(incoming_hash)
        if not should_insert:
            yaml_load_history_id = latest_row['yaml_load_history_id']
            self.latest_yaml_load_history_id = yaml_load_history_id
            self.logger.info(f"Skipping: yaml_hash matches latest record with {yaml_load_history_id = }.")
            return yaml_load_history_id

        # Perform append operation
        self.delta_manager.write_df(src_df, self.yaml_load_history_fqn, mode="append")

        self.latest_yaml_load_history_id = self._get_latest_yaml_load_history_id()
        self.logger.info("Inserted new YAML telemetry record...")
        return self.latest_yaml_load_history_id
