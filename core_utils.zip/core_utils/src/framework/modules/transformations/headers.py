"""
Header/Column Name Transformation utilities
- Rename, trim, case standardization, special character replacement
"""

import logging
import re
from pyspark.sql import DataFrame

logger = logging.getLogger(__name__)


class HeaderTransformations:
    """Transformations for DataFrame column headers (column names)"""

    _DELTA_INVALID_COL_PATTERN = re.compile(r"[ ,;{}()\n\t=]")

    @staticmethod
    def sanitize_column_names_for_delta(df: DataFrame) -> DataFrame:
        """
        Replace Delta-invalid characters and make top-level column names unique.
        """
        columns = df.columns
        if not columns:
            return df

        new_names = []
        changes = False
        used_names = set()
        next_suffix_by_base = {}

        for original_name in columns:
            # Normalize Delta-invalid characters to underscores.
            base_name = HeaderTransformations._DELTA_INVALID_COL_PATTERN.sub("_", original_name).strip("_")
            if not base_name:
                base_name = "col"

            # Create deterministic unique names: base, base_1, base_2, ...
            suffix = next_suffix_by_base.get(base_name, 0)
            final_name = base_name if suffix == 0 else f"{base_name}_{suffix}"
            while final_name in used_names:
                suffix += 1
                final_name = f"{base_name}_{suffix}"

            next_suffix_by_base[base_name] = suffix + 1
            used_names.add(final_name)

            new_names.append(final_name)
            if final_name != original_name:
                changes = True

        if changes:
            logger.info("Sanitized invalid characters in DataFrame column names for Delta compatibility.")
            return df.toDF(*new_names)
        return df

    @staticmethod
    def standardize_column_names(df: DataFrame, config: dict) -> DataFrame:
        """
        Standardize DataFrame column names based on configuration.

        Args:
            df (DataFrame): Input Spark DataFrame
            config (dict): Configuration dictionary with optional keys:
                - standardize_case (str): "lower" or "upper"
                - trim_whitespace (bool): Trim column name whitespace
                - replace_special_chars (dict): Special character rules
                - rename_map (dict): Column rename mapping

        Returns:
            DataFrame: DataFrame with standardized column names
        """
        logger.info("Starting standardize_column_names...")
        result = df

        # Apply column renaming if rename_map is present
        rename_map = config.get("rename_map")
        if rename_map:
            result = HeaderTransformations._rename_columns(result, rename_map)

        # Trim whitespace from column names
        if config.get("trim_whitespace"):
            result = HeaderTransformations._trim_column_names(result)

        # Apply column name case standardization
        case_option = config.get("standardize_case")
        if case_option in ("lower", "upper"):
            result = HeaderTransformations._apply_column_case(result, case_option)

        # Replace special characters in column names
        replace_cfg = config.get("replace_special_chars")
        if replace_cfg:
            result = HeaderTransformations._replace_special_chars_in_columns(result, replace_cfg)

        logger.info("Completed standardize_column_names.")
        return result

    @staticmethod
    def _rename_columns(df: DataFrame, rename_map: dict) -> DataFrame:
        """
        Rename columns based on provided mapping.

        Args:
            df (DataFrame): Input DataFrame
            rename_map (dict): Mapping of {old_column_name: new_column_name}

        Returns:
            DataFrame: DataFrame with renamed columns
        """
        missing_cols = [old_name for old_name in rename_map if old_name not in df.columns]
        present_map = {old_name: new_name for old_name, new_name in rename_map.items() if old_name in df.columns}

        result = df
        for idx, (old_name, new_name) in enumerate(present_map.items(), 1):
            result = result.withColumnRenamed(old_name, new_name)
            logger.info(f"   [{idx}] Renamed column: '{old_name}' -> '{new_name}'")

        if missing_cols:
            logger.warning(f"Columns not present in DataFrame; skipping rename: {missing_cols}")
        if not present_map:
            logger.info("No columns were renamed; none of the specified columns exist in DataFrame.")

        return result

    @staticmethod
    def _trim_column_names(df: DataFrame) -> DataFrame:
        """
        Trim leading and trailing whitespace from all column names.

        Args:
            df (DataFrame): Input DataFrame

        Returns:
            DataFrame: DataFrame with trimmed column names
        """
        rename_map = {}
        has_whitespace = False

        # Iterate through each column name
        for col in df.columns:
            trimmed_col = col.strip()
            # Check if trimming changes the column name
            if trimmed_col != col:
                has_whitespace = True
                # Only rename if trimmed name is not empty and does not duplicate an existing column
                if trimmed_col and trimmed_col not in df.columns:
                    rename_map[col] = trimmed_col
                    logger.info(f"Trimmed whitespace from column '{col}' to '{trimmed_col}'")
                else:
                    logger.warning(f"Trimmed column name '{trimmed_col}' is invalid or duplicates existing column; skipping rename for '{col}'.")

        # Log if no columns required trimming
        if not has_whitespace:
            logger.info("No column names have leading or trailing whitespace.")

        # Apply renaming if any columns were trimmed
        if rename_map:
            df = HeaderTransformations._rename_columns(df, rename_map)

        return df

    @staticmethod
    def _apply_column_case(df: DataFrame, case_option: str) -> DataFrame:
        """
        Apply case standardization to column names.

        Args:
            df (DataFrame): Input DataFrame
            case_option (str): Either 'lower' or 'upper'

        Returns:
            DataFrame: DataFrame with standardized column name casing
        """
        rename_map = {}

        for col in df.columns:
            new_col = col.lower() if case_option == "lower" else col.upper()
            if new_col != col:
                rename_map[col] = new_col

        if rename_map:
            df = HeaderTransformations._rename_columns(df, rename_map)
            logger.info("Applied %s casing to column names", case_option)

        return df

    @staticmethod
    def _replace_special_chars_in_columns(
        df: DataFrame,
        config: dict
    ) -> DataFrame:
        """
        Replace special characters in column names using global and
        column-specific replacement rules.

        Args:
            df (DataFrame): Input DataFrame
            config (dict): Special character replacement configuration

        Returns:
            DataFrame: DataFrame with updated column names
        """
        rename_map = {}

        global_rules = config.get("global", [])
        column_rules = config.get("columns", {})

        for col in df.columns:
            new_col = col

            # Apply global rules to all columns
            for rule in global_rules:
                special_char = rule.get("special_char")
                replacement = rule.get("with", "")
                if special_char is not None:
                    new_col = new_col.replace(special_char, replacement)

            # Apply column-specific rules
            for rule in column_rules.get(col, []):
                special_char = rule.get("special_char")
                replacement = rule.get("with", "")
                if special_char is not None:
                    new_col = new_col.replace(special_char, replacement)

            if new_col != col:
                rename_map[col] = new_col

        if rename_map:
            df = HeaderTransformations._rename_columns(df, rename_map)
            logger.info("Applied special character replacements to column names")

        return df