"""
DataTransformations: Data value and row-level transformation operations.

This class handles all data transformation operations that modify row values,
add new columns, or filter rows. Operations are organized into:
  - Column-level: Add, modify, or remove columns
  - Row-level: Filter, deduplicate, aggregate, or fill rows

Typical usage:
    from framework.modules.transformations import DataTransformations
    df = DataTransformations.add_metadata_columns(df, config)
    df = DataTransformations.standardize_data(spark, df, config)
    df = DataTransformations.remove_duplicates(df, config)
"""

import logging
from pyspark.sql import SparkSession, DataFrame, Window
from pyspark.sql import functions as F
from framework.core.enum import AuditColumns

logger = logging.getLogger(__name__)


class DataTransformations:
    """Handles all data-level transformations for DataFrames."""

    # ============================================================================
    # COLUMN-LEVEL OPERATIONS: Add, modify, or manage columns
    # ============================================================================

    @staticmethod
    def add_metadata_columns(df: DataFrame, args, file_name: str = None) -> DataFrame:
        """
        Add standard metadata columns to DataFrame.

        Args:
            df: Input DataFrame
            args: Arguments object with job/run/email/correlation IDs
            file_name (Optional): File name to use for the 'file_name' column

        Returns:
            DataFrame with metadata columns added
        """
        # Extract metadata values from args object
        job_id = getattr(args, "databricks_job_id", None)
        run_id = getattr(args, "databricks_run_id", None)
        email_id = getattr(args, "email_id", None)
        correlation_id = getattr(args, "correlation_id", None)

        if file_name:
            file_name_col = F.lit(file_name)
        elif AuditColumns.FILE_NAME.value in df.columns:
            file_name_col = F.col(AuditColumns.FILE_NAME.value)
        else:
            file_name_col = F.col("_metadata.file_name")

        # Define metadata columns to add
        metadata_columns = {
            AuditColumns.FILE_NAME.value: file_name_col,
            AuditColumns.CORRELATION_ID.value: F.lit(correlation_id).cast("string"),
            AuditColumns.DATABRICKS_JOB_ID.value: F.lit(job_id),
            AuditColumns.DATABRICKS_RUN_ID.value: F.lit(run_id),
            AuditColumns.LOAD_CREATE_USER_ID.value: F.lit(email_id).cast("string"),
            AuditColumns.LOAD_UPDATE_USER_ID.value: F.lit(None).cast("string"),
            AuditColumns.LOAD_CREATE_DTM.value: F.current_timestamp(),
            AuditColumns.LOAD_UPDATE_DTM.value: F.lit(None).cast("timestamp")
        }

        # Add metadata columns to DataFrame
        df = df.withColumns(metadata_columns)

        logger.info("Added metadata columns.")
        return df

    @staticmethod
    def add_custom_columns(df: DataFrame, config: dict) -> DataFrame:
        """
        Add custom calculated columns to the DataFrame based on the provided configuration.

        Args:
            df: Input DataFrame
            config: List of dicts [{'name': ..., 'expr': ...}] under 'with_columns'

        Returns:
            DataFrame with new columns
        """
        # Extract custom column definitions from config
        columns = config.get("with_columns", [])
        if not columns:
            logger.info("No custom columns specified in config; returning original DataFrame.")
            return df
        
        logger.info(f"Adding {len(columns)} column(s):")
        exprs = {}
        # Build expressions for each custom column
        for idx, col in enumerate(columns, 1):
            col_name = col.get("name")
            col_expression = col.get("expr")
            if col_name and col_expression:
                exprs[col_name] = F.expr(col_expression)
                logger.info(f"   [{idx}] name: {col_name}")
                logger.info(f"   [{idx}] expression: {col_expression}")
            else:
                logger.warning(f"[{idx}] Missing name or expression for custom column.")
        if exprs:
            try:
                # Add all custom columns to DataFrame at once
                df = df.withColumns(exprs)
            except Exception as e:
                logger.warning(f"Failed to add custom columns: {str(e)}")

        logger.info("Completed add_custom_columns.")
        return df
  
    @staticmethod
    def apply_casts(df: DataFrame, config: dict) -> DataFrame:
        """
        Cast specified columns to given types using config dictionary.

        Args:
            df: Input DataFrame
            config: Dictionary containing 'casts' key with list of dicts {'column': ..., 'to_type': ...}

        Returns:
            DataFrame with columns cast to specified types
        """
        # Extract cast instructions from config
        casts = (config.get("casts", []) or [])
        for cast in casts:
            col_name = cast.get("column")
            to_type = cast.get("to_type")
            # Only cast if column exists and target type is specified
            if col_name in df.columns and to_type:
                df = df.withColumn(col_name, F.col(col_name).cast(to_type))
                logger.info(f"Casted column {col_name} to {to_type}.")
            else:
                logger.warning(f"Column {col_name} not found or to_type missing for casting.")

        logger.info("Completed apply_casts.")
        return df

    @staticmethod
    def add_row_hash(
        df: DataFrame,
        columns_included: list = None,
        columns_excluded: list = None,
        hash_column_name: str = "row_hash",
        sep: str = "||"
    ) -> DataFrame:
        """
        Adds a SHA-256 hash column to the dataframe with customizable column name and separator.

        Args:
            df: Input DataFrame
            columns_included: List of columns to include in hash (default: all columns)
            columns_excluded: List of columns to exclude from hash (default: None)
            hash_column_name: Name of the hash column to add (default: 'row_hash')
            sep: Separator used to concatenate column values (default: '||')

        Returns:
            DataFrame with hash column added
        """
        
        # If no columns_included specified, use all columns
        if columns_included is None:
            columns_included = df.columns

        # Exclude specified columns from hash
        if columns_excluded:
            columns_included = [c for c in columns_included if c not in columns_excluded]

        # Concatenate column values with separator and cast to string
        concat_columns_expr = F.concat_ws(sep, *[F.col(f"`{c}`").cast("string") for c in columns_included])
        # Compute SHA-256 hash and add as new column
        hashed_df = df.withColumn(hash_column_name, F.sha2(concat_columns_expr, 256))

        return hashed_df

    @staticmethod
    def move_columns_to_end(df: DataFrame, cols) -> DataFrame:
        """
        Move one or more columns to the end of a DataFrame.
        Args:
            df (DataFrame): Input DataFrame
            cols (str | list[str]): Column name or list of column names to move
        Returns:
            DataFrame: DataFrame with specified columns moved to the end
        """
        if isinstance(cols, str):
            cols = [cols]
        existing_cols = df.columns

        # Keep only columns that actually exist in DF
        cols_to_move = [c for c in cols if c in existing_cols]
        remaining_cols = [c for c in existing_cols if c not in cols_to_move]
        return df.select(*remaining_cols, *cols_to_move)

    @staticmethod
    def drop_columns(df: DataFrame, columns: list) -> DataFrame:
        """
        Drop specified columns.

        Args:
            df: Input DataFrame
            columns: List of column names to drop

        Returns:
            DataFrame with columns dropped
        """
        logger.info(f"Dropping columns: {columns}")
        existing_cols = [col for col in columns if col in df.columns]
        df = df.drop(*existing_cols)
        logger.info(f"Dropped {len(existing_cols)} columns")
        return df

    @staticmethod
    def select_columns(df: DataFrame, columns: list) -> DataFrame:
        """
        Select only specified columns.

        Args:
            df: Input DataFrame
            columns: List of column names to keep

        Returns:
            DataFrame with only specified columns
        """
        existing_cols = [col for col in columns if col in df.columns]
        df = df.select(*existing_cols)
        logger.info(f"Selected {len(existing_cols)} columns")
        return df

    @staticmethod
    def cast_all_columns_to_string(df: DataFrame) -> DataFrame:
        """
        Cast all columns in the DataFrame to string type.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with all columns cast to string
        """
        logger.info("Casting all columns to string...")
        for col_name in df.columns:
            df = df.withColumn(col_name, F.col(col_name).cast("string"))
        logger.info("Completed cast_all_columns_to_string.")
        return df

    @staticmethod
    def standardize_data(spark: SparkSession, df: DataFrame, config: dict) -> DataFrame:
        """
        Standardize DataFrame data values based on config.

        Args:
            spark: SparkSession
            df: Input DataFrame
            config: Dictionary with standardization options for data values:
                - case (str): "lower" or "upper" for string columns
                - trim_strings (bool): Trim whitespace from all strings
                - strip_whitespace (list): Specific columns to trim
                - lowercase (list): Specific columns to convert to lower
                - uppercase (list): Specific columns to convert to upper

        Returns:
            DataFrame with standardized data values
        """
        result = df

        logger.info("Starting standardize_data...")

        # Warn if config contains any unhandled keys
        handled_keys = {"case", "trim_strings", "strip_whitespace", "lowercase", "uppercase"}
        unhandled_keys = set(config.keys()) - handled_keys
        if unhandled_keys:
            logger.warning(f"Unhandled config keys in standardize_data: {list(unhandled_keys)}")

        # Handle case transformation for all string columns
        case_option = config.get("case")
        if case_option in ("lower", "upper"):
            result = DataTransformations._apply_case(result, case_option)

        # Handle trim_strings
        if config.get("trim_strings"):
            result = DataTransformations._trim_strings(result)

        # Handle strip_whitespace
        strip_cols = config.get("strip_whitespace", [])
        if strip_cols:
            result = DataTransformations._strip_whitespace(result, strip_cols)

        # Handle lowercase (specific columns)
        lower_cols = config.get("lowercase", [])
        if lower_cols:
            result = DataTransformations._lowercase_columns(result, lower_cols)

        # Handle uppercase (specific columns)
        upper_cols = config.get("uppercase", [])
        if upper_cols:
            result = DataTransformations._uppercase_columns(result, upper_cols)

        logger.info("Completed standardize_data.")
        return result

    # ============================================================================
    # HELPER METHODS FOR standardize_data
    # ============================================================================

    @staticmethod
    def _apply_case(df: DataFrame, case_option: str) -> DataFrame:
        # Apply lower/upper case to all string columns except audit columns and row_hash
        cols_to_exclude = set(AuditColumns.values())
        cols_to_exclude.add("row_hash")
        cols = df.columns
        dtypes = dict(df.dtypes)
        exprs = {}
        for c in cols:
            if dtypes.get(c) in ("string", "varchar") and c not in cols_to_exclude:
                if case_option == "lower":
                    exprs[c] = F.lower(F.col(f"`{c}`"))
                elif case_option == "upper":
                    exprs[c] = F.upper(F.col(f"`{c}`"))
        if exprs:
            df = df.withColumns(exprs)
            logger.info(f"Applied {case_option} case to all string columns (excluding audit columns and row_hash)")
        return df

    @staticmethod
    def _trim_strings(df: DataFrame) -> DataFrame:
        """Trim whitespace from all string columns"""
        cols = df.columns
        dtypes = dict(df.dtypes)
        exprs = {}
        for c in cols:
            if dtypes.get(c) in ("string", "varchar"):
                exprs[c] = F.trim(F.col(f"`{c}`"))
        if exprs:
            df = df.withColumns(exprs)
            logger.info("Trimmed all string columns (trim_strings=True)")
        return df

    @staticmethod
    def _strip_whitespace(df: DataFrame, strip_cols: list) -> DataFrame:
        """Strip whitespace for specific columns"""
        exprs = {c: F.trim(F.col(f"`{c}`")) for c in strip_cols if c in df.columns}
        if exprs:
            df = df.withColumns(exprs)
            logger.info(f"Stripped whitespace for columns: {list(exprs.keys())}")
        return df

    @staticmethod
    def _lowercase_columns(df: DataFrame, lower_cols: list) -> DataFrame:
        """Lowercase specific columns"""
        exprs = {c: F.lower(F.col(f"`{c}`")) for c in lower_cols if c in df.columns}
        if exprs:
            df = df.withColumns(exprs)
            logger.info(f"Lowercased columns: {list(exprs.keys())}")
        return df

    @staticmethod
    def _uppercase_columns(df: DataFrame, upper_cols: list) -> DataFrame:
        """Uppercase specific columns"""
        exprs = {c: F.upper(F.col(f"`{c}`")) for c in upper_cols if c in df.columns}
        if exprs:
            df = df.withColumns(exprs)
            logger.info(f"Uppercased columns: {list(exprs.keys())}")
        return df

    # ============================================================================
    # ROW-LEVEL OPERATIONS: Filter, deduplicate, aggregate, or fill rows
    # ============================================================================

    @staticmethod
    def remove_duplicates(df: DataFrame, config: dict) -> DataFrame:
        """
        Remove duplicates, optionally using a tie breaker column.

        Args:
            df: Input DataFrame
            config: Dictionary containing:
                - 'on_columns': Columns to consider for deduplication
                - 'tie_breakers': List of dicts [{'column': ..., 'order': ...}] (optional)

        Returns:
            DataFrame with duplicates removed
        """
        columns = config.get("on_columns")

        # Default to 'row_hash' if no columns specified and 'row_hash' exists
        if not columns:
            columns = ['row_hash'] if 'row_hash' in df.columns else []
            logger.warning(f"on_columns key not found in deduplicate config; using {columns} column for deduplication.")

        tie_breakers = config.get("tie_breakers", [])

        # Warn if any specified columns are missing from DataFrame
        missing_cols = [col for col in columns if col not in df.columns]
        if missing_cols:
            logger.warning(f"Defined on_columns not found in DataFrame: {missing_cols}")

        if columns:
            if tie_breakers:
                logger.info(f"Removing duplicates using:")
                logger.info(f"   columns: {columns}")
                logger.info(f"   tie breakers: {tie_breakers}")
                # Use window function to rank rows within each group, based on tie breaker columns
                order_exprs = [
                    F.desc(tb["column"]) if tb.get("order", "desc").lower() == "desc" else F.asc(tb["column"])
                    for tb in tie_breakers if tb["column"] in df.columns
                ]
                window_spec = Window.partitionBy(*columns).orderBy(*order_exprs)
                df = df.withColumn("_row_rank", F.row_number().over(window_spec))
                # Keep only the first row in each group
                df = df.filter(F.col("_row_rank") == 1).drop("_row_rank")
            else:
                logger.info(f"Removing duplicates based on columns: {columns}")
                # Remove duplicates based on specified columns
                df = df.dropDuplicates(columns)
        else:
            logger.warning("No columns specified for deduplication; returning original DataFrame.")
            return df  # Return original DataFrame if no columns specified

        logger.info("Completed remove_duplicates.")
        return df

    @staticmethod
    def fill_nulls(df: DataFrame, fill_values: dict) -> DataFrame:
        """
        Fill null values with specified defaults.

        Args:
            df: Input DataFrame
            fill_values: Dictionary of {column: fill_value}

        Returns:
            DataFrame with nulls filled
        """
        logger.info(f"Filling null values in columns: {list(fill_values.keys())}")
        df = df.fillna(fill_values)
        logger.info(f"Filled null values in {len(fill_values)} columns")
        return df

    @staticmethod
    def apply_filters(df: DataFrame, config: dict) -> DataFrame:
        """
        Apply filter expressions from config to DataFrame.

        Args:
            df: Input DataFrame
            config: Dictionary containing "filters" as a list of SQL expressions

        Returns:
            DataFrame with filters applied
        """
        filters = config.get("filters", [])

        for filter_expr in filters:
            logger.info(f"Applying filter: {filter_expr}")
            df = df.filter(F.expr(filter_expr))

        logger.info("Completed apply_filters.")
        return df

    @staticmethod
    def apply_aggregations(df: DataFrame, config: dict) -> DataFrame:
        """
        Apply group-by aggregation operations.

        Args:
            df: Input DataFrame
            config: Dictionary containing:
                - 'group_by': List of column names to group by
                - 'metrics': List of dicts {'name': ..., 'expr': ...} for aggregation

        Returns:
            Aggregated DataFrame
        """
        group_by = config.get("group_by", [])
        metrics = config.get("metrics", [])

        # If no group_by or metrics specified, return original DataFrame
        if not group_by or not metrics:
            logger.info(
                "No group_by or metrics specified for aggregation; "
                "returning original DataFrame"
            )
            return df

        # Group DataFrame by specified columns
        grp = df.groupBy([F.col(c) for c in group_by])
        # Build aggregation expressions from metrics config
        agg_exprs = [F.expr(m["expr"]).alias(m["name"]) for m in metrics if "expr" in m and "name" in m]
        logger.info("Applying aggregations with arguments:")
        logger.info(f"  group_by: {group_by}")
        logger.info(f"  metrics:")
        for idx, metric in enumerate(metrics, 1):
            for k, v in metric.items():
                logger.info(f"    [{idx}] {k}: {v}")
        logger.info("Completed apply_aggregations.")
        return grp.agg(*agg_exprs)