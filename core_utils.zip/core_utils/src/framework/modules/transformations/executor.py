"""
Transformation utilities for Databricks Delta Lake processing.

Provides transformation orchestration and utilities:
- HeaderTransformations: Column name operations
- DataTransformations: Data value operations
- TransformationExecutor: Execution orchestration and sequencing
"""

import logging
from pyspark.sql import SparkSession, DataFrame

from .headers import HeaderTransformations
from .data import DataTransformations

logger = logging.getLogger(__name__)


class TransformationExecutor:
    """Orchestrates and sequences transformation steps"""

    @staticmethod
    def build_step_map(config: list = None, step_names: list = None) -> dict:
        """
        Build step function map from available transformations.

        Args:
            step_names (list, optional): Specific steps to include.
                                        If None, includes all available steps.

        Returns:
            dict: Mapping of step names to transformation functions
        """
        # Define available transformation steps and their corresponding functions
        available_steps = {
            # --- Header transformation steps ---
            "standardize_column_names": HeaderTransformations.standardize_column_names,

            # --- Data transformation steps ---
            "standardize_data": DataTransformations.standardize_data,
            "with_columns": DataTransformations.add_custom_columns,
            "casts": DataTransformations.apply_casts,
            "deduplicate": DataTransformations.remove_duplicates,
            "fill_nulls": DataTransformations.fill_nulls,
            "drop_columns": DataTransformations.drop_columns,
            "select_columns": DataTransformations.select_columns,
            "filters": DataTransformations.apply_filters,
            "aggregations": DataTransformations.apply_aggregations,
            "add_row_hash": DataTransformations.add_row_hash,
            "cast_all_columns_to_string": DataTransformations.cast_all_columns_to_string,
            "move_columns_to_end": DataTransformations.move_columns_to_end,
        }

        # If specific step names are provided, filter the available steps
        if step_names:
            step_map = {k: v for k, v in available_steps.items() if k in step_names}
            if config:
                config_steps = [step.get("step") for step in config if "step" in step]
                missing_steps = [s for s in config_steps if s not in step_names]
                if missing_steps:
                    logger.warning(f"Requested steps not found: {missing_steps}")
            return step_map

        # Return all available steps if no specific step names are provided
        return available_steps

    @staticmethod
    def apply_transformations(
        spark: SparkSession,
        df: DataFrame,
        config: list,
        transformation_step: list
    ) -> DataFrame:
        """
        Apply a sequence of transformation steps to a DataFrame using provided function map.

        Args:
            spark: SparkSession
            df: Input DataFrame
            config: List of step dictionaries with 'step', and 'config'
            transformation_step: List of step names to include in the function map

        Returns:
            DataFrame after applying all transformation steps
        """
        logger.info("Starting apply_transformations with %d steps.", len(config))
        # Build step function map based on transformation_step input
        step_func_map = TransformationExecutor.build_step_map(config, transformation_step)
        # Iterate through each step and apply the corresponding transformation
        for step in config:
            step_name = step.get("step")
            step_config = step.get("config", {})
            if step_name in step_func_map:
                logger.info(f"Applying step: {step_name}")
                func = step_func_map[step_name]
                # Call function with SparkSession for 'standardize', else just DataFrame and config
                if step_name == "standardize_data":
                    df = func(spark, df, step_config)
                else:
                    df = func(df, step_config)

        logger.info("Completed apply_transformations.")
        # Return transformed DataFrame
        return df


__all__ = [
    'TransformationExecutor',
    'HeaderTransformations',
    'DataTransformations',
]