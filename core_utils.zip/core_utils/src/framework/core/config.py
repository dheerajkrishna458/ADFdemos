import yaml
import os
import re
import logging
from typing import Dict, Any


class ConfigManager:
    """Load, parse, and validate YAML configuration files"""

    # ---- Structural rules ----
    TOP_LEVEL_KEYS = ["pipeline", "source", "target"]
    PIPELINE_KEYS = ["name", "layer"]
    DESTINATION_KEYS = ["mode", "format", "table"]

    # ---- Semantic rules ----
    DESTINATION_MODES = {"overwrite", "append", "merge"}

    BRONZE_SOURCE_TYPE = "file"
    SILVER_GOLD_SOURCE_TYPE = "delta_table"

    # ---- Bronze source formats ----
    BRONZE_SOURCE_FORMATS = {"csv", "json", "parquet", "cobol", "text"}

    # ---- Mandatory properties ----
    BRONZE_SOURCE_REQUIRED_PROPS = ["format", "extension", "source_path"]
    SILVER_GOLD_SOURCE_REQUIRED_PROPS = ["format", "table"]

    def __init__(self, args):
        # Initialize logger and arguments
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self.args = args

    def read_config(self, file_path: str) -> Dict[str, Any]:
        """Read and parse a YAML file."""
        with open(file_path, 'r') as f:
            config = yaml.safe_load(f)

        return config

    def load_config(self) -> None:
        """Load YAML config file and set attributes for optimization"""
        # Build config file path from args
        config_file_path = os.path.join(self.args.config_directory_path,
                                        self.args.config_catalog,
                                        self.args.layer,
                                        self.args.config_file_name)

        # Check if config file exists
        if not os.path.exists(config_file_path):
            raise Exception(
                f"Provided config path doesn't exists, Please validate the path -> {config_file_path}"
            )

        self.logger.info(f"Loading config from: {config_file_path}")

        # Read and validate config
        config = self.read_config(config_file_path)
        self.validate_yaml_config(config)
        self.logger.info(f"Config validated and loaded successfully")

        # Set config and config file path as attributes
        self.config = config
        self.config_file_path = config_file_path

    def validate_yaml_config(self, config: Dict[str, Any]) -> None:
        """Validate YAML config structure and semantics."""
        self._validate_structure(config)
        self._validate_semantics(config)

    def _validate_structure(self, config: Dict[str, Any]) -> None:
        """Validate config structure."""
        # ---- Top level ----
        for key in self.TOP_LEVEL_KEYS:
            if key not in config:
                raise ValueError(f"Missing mandatory top-level key: {key}")

        # ---- pipeline ----
        metadata = config["pipeline"]
        for key in self.PIPELINE_KEYS:
            if key not in metadata:
                raise ValueError(f"Missing pipeline.{key}")

        # ---- target ----
        target = config["target"]
        for key in self.DESTINATION_KEYS:
            if key not in target:
                raise ValueError(f"Missing target.{key}")

        # ---- security.masking ----
        security = config.get("security")
        if security and security.get("masking"):
            for idx, rule in enumerate(security["masking"]):
                if "column" not in rule or "policy" not in rule:
                    raise ValueError(
                        f"Invalid masking rule at index {idx}: "
                        f"'column' and 'policy' are required"
                    )

    def _validate_semantics(self, config: Dict[str, Any]) -> None:
        """Validate config semantics."""
        layer = config["pipeline"]["layer"]

        if layer == "bronze":
            self._validate_bronze(config)
        elif layer in {"silver", "gold"}:
            self._validate_silver_gold(config, layer)
        else:
            raise ValueError(f"Unsupported pipeline layer: {layer}")

    # ---------------------- BRONZE ----------------------
    def _validate_bronze(self, config: Dict[str, Any]) -> None:
        """Validate bronze layer config."""
        source = config["source"]

        if source.get("type") != self.BRONZE_SOURCE_TYPE:
            raise ValueError("Bronze source.type must be 'file'")

        properties = source.get("properties")
        if not properties:
            raise ValueError("source.properties is mandatory for bronze")

        for key in self.BRONZE_SOURCE_REQUIRED_PROPS:
            if key not in properties:
                raise ValueError(f"Missing source.properties.{key}")

        if properties["format"] not in self.BRONZE_SOURCE_FORMATS:
            raise ValueError(
                f"source.properties.format must be one of {self.BRONZE_SOURCE_FORMATS}"
            )

        self._validate_target(config)

    # ------------------ SILVER / GOLD ------------------
    def _validate_silver_gold(self, config: Dict[str, Any], layer: str) -> None:
        """Validate silver/gold layer config."""
        source = config["source"]

        if source.get("type") != self.SILVER_GOLD_SOURCE_TYPE:
            raise ValueError(f"{layer} source.type must be 'delta_table'")

        properties = source.get("properties")
        if not properties:
            raise ValueError("source.properties is mandatory")

        for key in self.SILVER_GOLD_SOURCE_REQUIRED_PROPS:
            if key not in properties:
                raise ValueError(f"Missing source.properties.{key}")

        self._validate_table_fqn(properties["table"])
        self._validate_target(config)
        
    def _validate_target(self, config: Dict[str, Any]) -> None:
        """Validate target config."""
        target = config["target"]

        if target["mode"] not in self.DESTINATION_MODES:
            raise ValueError(
                f"target.mode must be one of {self.DESTINATION_MODES}"
            )

        self._validate_table_fqn(target["table"])

    def _validate_table_fqn(self, table: str) -> None:
        """Validate table fully qualified name."""
        if not re.match(r"^[^.]+\.[^.]+\.[^.]+$", table):
            raise ValueError(
                f"Invalid table format '{table}'. Expected catalog.schema.table"
            )