from enum import Enum


class Environment(str, Enum):
    """Environment type."""
    DEV = "dev"
    BETA = "beta"
    PROD = "prod"


class Layer(str, Enum):
    """Data layer type."""
    BRONZE = "bronze"
    SILVER = "silver"
    GOLD = "gold"
    # SNOWFLAKE = "snowflake"


class LoadStatus(str, Enum):
    """Represents the load status of a file or run."""
    SUCCESS = "Success"
    FAILURE = "Failed"
    # THRESHOLD_FAILURE = "Threshold Failure"
    # DELETE = "Delete"


class LoadStageName(str, Enum):
    """Load stage name."""
    RAW_TO_BRONZE = "RawToBronze"
    BRONZE_TO_SILVER = "BronzeToSilver"
    SILVER_TO_GOLD = "SilverToGold"
    UNKNOWN = "UnknownStage"

    @classmethod
    def from_layer(cls, layer: str):
        """Get LoadStageName from layer string."""
        mapping = {
            "bronze": cls.RAW_TO_BRONZE,
            "silver": cls.BRONZE_TO_SILVER,
            "gold": cls.SILVER_TO_GOLD,
        }
        return mapping.get(layer.lower(), cls.UNKNOWN)


class LoadTypeName(str, Enum):
    """Represents how the load was triggered."""
    PIPELINE = "Pipeline"
    MANUAL = "Manual"


class OperationType(str, Enum):
    """Represents the type of data operation performed."""
    APPEND = "APPEND"
    OVERWRITE = "OVERWRITE"
    MERGE = "MERGE"

    @classmethod
    def from_mode(cls, mode: str):
        """Get OperationType from mode string."""
        mapping = {
            "append": cls.APPEND,
            "overwrite": cls.OVERWRITE,
            "merge": cls.MERGE,
        }
        return mapping.get(mode)


class AuditColumns(str, Enum):
    """Audit column names."""
    FILE_NAME = "file_name"
    CORRELATION_ID = "correlation_id"
    DATABRICKS_JOB_ID = "databricks_job_id"
    DATABRICKS_RUN_ID = "databricks_run_id"
    LOAD_CREATE_USER_ID = "load_create_user_id"
    LOAD_UPDATE_USER_ID = "load_update_user_id"
    LOAD_CREATE_DTM = "load_create_dtm"
    LOAD_UPDATE_DTM = "load_update_dtm"

    @classmethod
    def values(cls):
        """Return set of audit column values."""
        return {item.value for item in cls}