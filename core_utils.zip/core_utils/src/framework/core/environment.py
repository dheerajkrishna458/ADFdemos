import logging
from typing import Optional
from pyspark.sql import SparkSession

from .enum import Environment

class EnvironmentManager:
    """
    Simple environment manager that infers environment from Databricks workspace URL
    and helps construct Unity Catalog volume/catalog and source paths.
    """

    WORKSPACE_TO_ENV = {
        "adb-5637650859544783.3.azuredatabricks.net": Environment.DEV,
        "adb-4300184777753314.14.azuredatabricks.net": Environment.BETA,
        "adb-4725979452643860.0.azuredatabricks.net": Environment.PROD,
    }
    def __init__(self, spark: Optional[SparkSession], args):
        """
        :param spark: pyspark.sql.SparkSession (in Databricks this is the existing spark object)
        :param default_env: fallback environment when workspace URL is unknown
        """
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self.spark = spark
        self.args = args

        # Workspace attribute
        self.workspace_url = self.spark.conf.get("spark.databricks.workspaceUrl", "") or ""
        self.workspace_name = self.get_workspace_name()
        self.env = self._get_workspace_env()

        # Prefix used when constructing catalog names: dev -> "dev_"
        self.env_prefix = f"{self.env.value}_"

        # Attribute for sandbox
        self.catalog = None
        self.schema = None

        # If in dev environment and schema is provided, set sandbox catalog/schema from args
        if self.env == Environment.DEV and self.args.test_schema is not None:
            self._set_sandbox_catalog_schema()

    def _set_sandbox_catalog_schema(self):
        self.logger.info(f"Sandbox environment detected!!!")
        self.catalog = self.args.test_catalog
        self.schema = self.args.test_schema
        self.logger.info(f"Sandbox details set: catalog='{self.catalog}', schema='{self.schema}'")

    def _get_workspace_env(self) -> Environment:
        """Determines the environment based on the Databricks workspace URL."""
        env = self.WORKSPACE_TO_ENV.get(self.workspace_url)
        if env:
            return env
        self.logger.info(f"Unknown workspace URL '{self.workspace_url}'. Defaulting to 'dev'.")
        return Environment.DEV

    def get_workspace_name(self) -> Optional[str]:
        """Fetches the workspace_name from the system.access.workspaces_latest table."""
        df = (
            self.spark.table("system.access.workspaces_latest")
            .filter(f"workspace_url LIKE '%{self.workspace_url}'")
            .select("workspace_name")
            .limit(1)
        )
        result = df.first()
        if result:
            return result["workspace_name"]
        return None

    def construct_volume_catalog_name(self, catalog_base: str) -> str:
        """Constructs the full catalog name for a Unity Catalog volume."""
        return f"{self.env_prefix}{catalog_base}"

    def construct_source_folder_path(self, source_path: str) -> str:
        """Constructs the complete base path for provided source_path."""
        src_catalog = self.construct_volume_catalog_name("deltalake")
        full_path = f"/Volumes/{src_catalog}/raw{source_path}"
        return full_path

    def construct_catalog_name(self, catalog_base: str) -> str:
        """Constructs the full catalog name based on the environment.
        If test catalog is provided, returns test catalog.
        """
        if self.catalog:
            return f"{self.catalog}"
        return f"{self.env_prefix}{catalog_base}"

    def construct_schema_name(self, schema_name: str) -> str:
        """Constructs the schema name based on the environment.
        If test catalog is provided, returns test catalog.
        """
        if self.schema:
                return f"{self.schema}"
        return f"{schema_name}"

    def construct_table_name(self, schema_name: str, table: str) -> str:
        """Constructs the schema name based on the environment.
        If test catalog is provided, returns test catalog.
        """
        if self.schema:
                return f"{schema_name}_{table}"
        return table

    def _get_audit_catalog_schema(self) -> str:
        """Gets the FQN for the audit catalog and schema.
        If test schema is provided, returns test schema.
        """
        if self.schema:
            return f"{self.catalog}.{self.schema}"
        catalog = self.construct_catalog_name("deltalake_audit")
        return f"{catalog}.audit_logs"

    def parse_cleaned_table_path(self, table_fqn: str) -> tuple[str, str, str]:
        """Removes env prefix and splits FQN into catalog, schema, table."""
        parts = table_fqn.split(".")
        if len(parts) != 3:
            raise ValueError(f"Expected 3 components in table FQN, got {len(parts)}: '{table_fqn}'")
        return tuple(parts)

    def construct_table_fqn(self, table_fqn: str) -> str:
        """
        Constructs the Table FQN based on the environment.

        :param table_fqn: Fully qualified table name (without env prefix)
        :return: Environment-specific FQN for the table
        """
        # Remove env prefix and split FQN into catalog, schema, table
        catalog, schema, table = self.parse_cleaned_table_path(table_fqn)
        catalog_name = self.construct_catalog_name(catalog)
        schema_name = self.construct_schema_name(schema)
        table_name = self.construct_table_name(schema, table)

        # Return the fully qualified table name
        return f"{catalog_name}.{schema_name}.{table_name}"

    def get_error_logs_fqn(self) -> str:
        """Returns the FQN for the error_logs table.
        If test catalog and schema are provided, returns a test-specific FQN.
        """
        return f"{self._get_audit_catalog_schema()}.error_logs"

    def get_run_load_history_fqn(self) -> str:
        """Returns the FQN for the run_load_history table.
        If test catalog and schema are provided, returns a test-specific FQN.
        """
        return f"{self._get_audit_catalog_schema()}.run_load_history"

    def get_data_quality_exceptions_fqn(self) -> str:
        """Returns the FQN for the data_quality_exceptions table."""
        return f"{self._get_audit_catalog_schema()}.data_quality_exceptions"

    def get_data_quality_summary_fqn(self) -> str:
        """Returns the FQN for the data_quality_summary table."""
        return f"{self._get_audit_catalog_schema()}.data_quality_summary"

    def get_masking_function_fqn(self, function_nm: str) -> str:
        """Constructs the fully qualified name (FQN) for a masking function."""
        # Once the Masking functions creation logic is migrated to Repo, Below line should be used  
        # catalog_schema = self.get_protect_masking_catalog_schema()

        catalog = f"{self.env_prefix}protect"
        schema = "masking"
        return f"{catalog}.{schema}.{function_nm}"

    def get_code_log_table_fqn(self) -> str:
        """Returns the FQN for the code_logs table.
        If test catalog and schema are provided, returns a test-specific FQN.
        """
        return f"{self._get_audit_catalog_schema()}.code_logs"

    def get_yaml_load_history_fqn(self) -> str:
        """Returns the FQN for the yaml_load_history table.
        If test catalog and schema are provided, returns a test-specific FQN.
        """
        return f"{self._get_audit_catalog_schema()}.yaml_load_history"
