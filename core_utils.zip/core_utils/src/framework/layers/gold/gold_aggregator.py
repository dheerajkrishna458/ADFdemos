from pyspark.sql import DataFrame
from framework.core.base import MedallionBase
from framework.modules.transformations.executor import TransformationExecutor
from framework.modules.security.masker import Masker


class GoldAggregator(MedallionBase):
    """
    Gold Layer: Business-ready aggregations and reporting tables.
    """
    def __init__(self, args):
        """
        Initialize GoldAggregator with configs for pipeline, source, transform, and target.
        """
        super().__init__(args)

        # Load pipeline, source, transform, and target configs
        self.pipeline_config = self.config.get('pipeline', {})
        self.source_config = self.config.get('source', {})
        self.transform_config = self.config.get('transform', {})
        self.target_config = self.config.get('target', {})
    
    def transform(self, df: DataFrame) -> DataFrame:
        """Apply transformations for gold layer."""
        self.logger.info("Applying gold transformations...")

        # List of gold layer transformation steps
        transformation_steps = [
            "standardize_column_names",
            "standardize_data",
            "casts",
            "deduplicate",
            "with_columns",
            "aggregations",
            # Add more transformations steps as needed
        ]

        # Apply all the transformation as per mapping and in sequence
        df = TransformationExecutor.apply_transformations(
            self.spark, df, self.transform_config, transformation_steps
        )

        return df
    
    def load(self, df: DataFrame) -> None:
        """
        Write validated/cleaned data to gold table
        """
        target_table = self.env_manager.construct_table_fqn(self.target_config.get("table"))
        mode = self.target_config.get("mode", "append")

        self.logger.info(f"Loading data to {target_table} (mode: {mode})")

        if not target_table:
            raise ValueError("No target table configured in target_config.")

        if mode == "merge":
            merge_condition = self.target_config.get("merge_condition", None)
            update_dict = self.target_config.get("update_dict", None)
            insert_dict = self.target_config.get("insert_dict", None)
            update_condition = self.target_config.get("update_condition", None)
            update_all = self.target_config.get("update_all", None)
            insert_all = self.target_config.get("insert_all", None)
            self.delta_manager.merge_df(
                df,
                target_table,
                merge_condition,
                update_dict=update_dict,
                insert_dict=insert_dict,
                update_condition=update_condition,
                update_all=update_all,
                insert_all=insert_all,
                table_properties=self.delta_manager.gold_tbl_properties
            )
        elif mode == "append" or mode == "overwrite":
            self.delta_manager.write_df(df, target_table, mode, self.delta_manager.gold_tbl_properties)

    def run(self) -> None:
        """Customized run for gold layer"""
        target_table = self.env_manager.construct_table_fqn(self.target_config.get("table"))
        start_dtm = self.audit_logger._get_datetime_now()
        try:
            pipeline_name = self.pipeline_config.get("name")

            self.logger.info(f"Pipeline '{pipeline_name}' | Starting extract method...")
            df = self.extract()

            if df is None:
                self.logger.info(f"Pipeline '{pipeline_name}' | No data extracted, treating as success.")
                self.audit_logger.log_run_audit(df, self.config, "success", start_dtm)
                self.logger.info(f"Pipeline '{pipeline_name}' | Skipping further operation.")
                return

            self.logger.info(f"Pipeline '{pipeline_name}' | Starting transform method...")
            df = self.transform(df)

            self.logger.info(f"Pipeline '{pipeline_name}' | Starting load method...")
            self.load(df)

            masker = Masker(self.spark, self.args, self.config, self.env_manager)
            masker.apply_masking(df, target_table)

            self.audit_logger.log_run_audit(df, self.config, "success", start_dtm)

            self.logger.info(f"Pipeline '{pipeline_name}' | Successfully Completed.")

        except Exception as e:
            err_msg = (
                f"Error in pipeline = '{pipeline_name}' | "
                f"layer = '{self.args.layer}' | "
                f"config_file = '{self.args.config_file_name}': {str(e)}"
            )
            self.logger.error(err_msg, exc_info=True)
            self.audit_logger.log_error(e, err_msg)
            self.audit_logger.log_run_audit(None, self.config, "failure", start_dtm, exception=e)
            raise
        finally:
            self.audit_logger.log_run_summary()
