"""Gold layer module"""
