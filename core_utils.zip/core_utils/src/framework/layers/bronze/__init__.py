"""Bronze layer module"""
