"""Silver layer module"""
