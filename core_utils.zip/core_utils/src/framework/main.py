"""
CLI for Medallion Architecture pipeline

Entry points:
    run_bronze - Bronze layer (raw ingestion)
    run_silver - Silver layer (validation & cleansing)
    run_gold   - Gold layer (business aggregations)
"""
import logging
import inspect

from .core.arg_parser import ArgParser
from .layers.bronze.bronze_ingester import BronzeIngester
from .layers.silver.silver_refiner import SilverRefiner
from .layers.gold.gold_aggregator import GoldAggregator
from .core.enum import Layer
from .modules.utils.handle_dry_run import handle_dry_run
from .modules.logging.log_manager import LoggingConfigurator, RuntimeManager, UserCancelledException

# Setup root logger with custom formatting + buffering from the start
LoggingConfigurator.configure_console()
# Get module logger
logger = logging.getLogger(__name__)


RuntimeManager.enable_graceful_shutdown()


def run_layer(layer_name: str, layer_class):
    """
    Utility function to run a specific medallion layer.

    Args:
        layer_name: Name of the layer (bronze, silver, gold)
        layer_class: The class constructor for the layer
    """
    logger.info(f"----- STARTING {layer_name.upper()} LAYER EXECUTION -----")

    # Get the calling function's name for entry_point tracking
    caller = inspect.stack()[1].function

    # Parse CLI arguments
    args = ArgParser.parse(entry_point=caller, layer=layer_name)

    # Dry-run branch
    if getattr(args, "dry_run", "false").lower() == "true":
        handle_dry_run(args)
        return

    # Instantiate and run the layer
    layer = layer_class(args)
    try:
        layer.run()
    except UserCancelledException:
        logger.warning("%s layer execution cancelled by user or runtime signal.", layer_name.upper())
        raise SystemExit(130)
    except KeyboardInterrupt:
        logger.warning("%s layer execution cancelled by user.", layer_name.upper())
        raise SystemExit(130)
    else:
        logger.info(f"----- {layer_name.upper()} LAYER EXECUTION COMPLETED -----")
    finally:
        LoggingConfigurator.flush_and_detach_buffer_handlers(logger=logger)
        RuntimeManager.reset_termination_state()


def run_bronze():
    run_layer(Layer.BRONZE.value, BronzeIngester)


def run_silver():
    run_layer(Layer.SILVER.value, SilverRefiner)


def run_gold():
    run_layer(Layer.GOLD.value, GoldAggregator)


if __name__ == "__main__":
    print("Unknown layer, execute the correct entry_point()")
