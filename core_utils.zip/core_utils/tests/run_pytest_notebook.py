# Databricks notebook source
# MAGIC %md
# MAGIC # Pytest Runner
# MAGIC Run the following cell to run all pytests in the unit_tests folder.

# COMMAND ----------

# DBTITLE 1,To auto reload modules
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2

# COMMAND ----------

# DBTITLE 1,Execute pytest functions
import pytest, sys

sys.dont_write_bytecode = True
pytest.main([".", '-vv']) # "-p", "no:cacheprovider" is set by cluster
