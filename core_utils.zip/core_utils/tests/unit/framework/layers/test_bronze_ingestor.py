"""
Unit tests for framework.layers.bronze.bronze_ingester.BronzeIngester
"""

import sys
import types
import pytest
from unittest.mock import MagicMock, patch


# Access the loaded module from conftest via sys.modules
_bronze_mod = sys.modules["framework.layers.bronze.bronze_ingester"]
BronzeIngester = _bronze_mod.BronzeIngester


class TestBronzeIngesterInit:

    def test_init_loads_config_sections(self, patch_base_init, mock_args, bronze_config):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.pipeline_config = ingester.config.get("pipeline", {})
        ingester.source_config = ingester.config.get("source", {})
        ingester.transform_config = ingester.config.get("transform", {})
        ingester.target_config = ingester.config.get("target", {})
        assert ingester.pipeline_config == {"name": "test_bronze_pipeline"}
        assert ingester.source_config["type"] == "file"
        assert ingester.target_config["table"] == "catalog.schema.bronze_tbl"
        assert ingester.target_config["mode"] == "append"

    def test_init_files_discovered_empty(self, patch_base_init, mock_args):
        ingester = BronzeIngester(mock_args)
        assert ingester.files_discovered == []

    def test_init_sets_args(self, patch_base_init, mock_args):
        ingester = BronzeIngester(mock_args)
        assert ingester.args is mock_args

    def test_init_has_spark_session(self, patch_base_init, mock_args):
        ingester = BronzeIngester(mock_args)
        assert ingester.spark is not None


class TestBronzeTransform:

    def test_transform_applies_all_steps(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.transform_config = bronze_config["transform"]
        with patch.object(_bronze_mod, "HeaderTransformations") as MockHeaders, \
             patch.object(_bronze_mod, "TransformationExecutor") as MockExecutor, \
             patch.object(_bronze_mod, "DataTransformations") as MockData:
            MockHeaders.sanitize_column_names_for_delta.return_value = mock_dataframe
            MockData.add_metadata_columns.return_value = mock_dataframe
            MockData.add_row_hash.return_value = mock_dataframe
            MockExecutor.apply_transformations.return_value = mock_dataframe
            MockData.move_columns_to_end.return_value = mock_dataframe
            result = ingester.transform(mock_dataframe)
            MockHeaders.sanitize_column_names_for_delta.assert_called_once_with(mock_dataframe)
            MockData.add_metadata_columns.assert_called_once_with(mock_dataframe, mock_args)
            MockData.add_row_hash.assert_called_once()
            MockExecutor.apply_transformations.assert_called_once()
            MockData.move_columns_to_end.assert_called_once_with(mock_dataframe, ["row_hash"])
            assert result is mock_dataframe

    def test_transform_returns_dataframe(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.transform_config = bronze_config["transform"]
        with patch.object(_bronze_mod, "HeaderTransformations") as MockHeaders, \
             patch.object(_bronze_mod, "TransformationExecutor") as MockExecutor, \
             patch.object(_bronze_mod, "DataTransformations") as MockData:
            MockHeaders.sanitize_column_names_for_delta.return_value = mock_dataframe
            MockData.add_metadata_columns.return_value = mock_dataframe
            MockData.add_row_hash.return_value = mock_dataframe
            MockExecutor.apply_transformations.return_value = mock_dataframe
            MockData.move_columns_to_end.return_value = mock_dataframe
            result = ingester.transform(mock_dataframe)
            assert result is not None

    def test_transform_executor_receives_spark_and_config(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.transform_config = bronze_config["transform"]
        with patch.object(_bronze_mod, "HeaderTransformations") as MockHeaders, \
             patch.object(_bronze_mod, "TransformationExecutor") as MockExecutor, \
             patch.object(_bronze_mod, "DataTransformations") as MockData:
            MockHeaders.sanitize_column_names_for_delta.return_value = mock_dataframe
            MockData.add_metadata_columns.return_value = mock_dataframe
            MockData.add_row_hash.return_value = mock_dataframe
            MockExecutor.apply_transformations.return_value = mock_dataframe
            MockData.move_columns_to_end.return_value = mock_dataframe
            ingester.transform(mock_dataframe)
            call_args = MockExecutor.apply_transformations.call_args[0]
            assert call_args[0] is ingester.spark
            assert call_args[2] is ingester.transform_config


class TestBronzeLoad:

    def test_load_append_mode(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.target_config = bronze_config["target"]
        ingester.load(mock_dataframe)
        ingester.delta_manager.write_df.assert_called_once()
        assert ingester.delta_manager.write_df.call_args[0][2] == "append"

    def test_load_overwrite_mode(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        bronze_config["target"]["mode"] = "overwrite"
        ingester.config = bronze_config
        ingester.target_config = bronze_config["target"]
        ingester.load(mock_dataframe)
        assert ingester.delta_manager.write_df.call_args[0][2] == "overwrite"

    def test_load_merge_mode(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        bronze_config["target"]["mode"] = "merge"
        bronze_config["target"]["merge_condition"] = "tgt.id = src.id"
        ingester.config = bronze_config
        ingester.target_config = bronze_config["target"]
        ingester.load(mock_dataframe)
        ingester.delta_manager.merge_df.assert_called_once()
        assert ingester.delta_manager.merge_df.call_args[0][2] == "tgt.id = src.id"

    def test_load_raises_when_no_target_table(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        bronze_config["target"]["table"] = None
        ingester.config = bronze_config
        ingester.target_config = bronze_config["target"]
        ingester.env_manager.construct_table_fqn.return_value = None
        with pytest.raises(ValueError, match="No target table configured"):
            ingester.load(mock_dataframe)

    def test_load_uses_bronze_tbl_properties(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.target_config = bronze_config["target"]
        ingester.load(mock_dataframe)
        assert ingester.delta_manager.write_df.call_args[0][3] == ingester.delta_manager.bronze_tbl_properties


class TestBronzeRun:

    def test_run_happy_path(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.pipeline_config = bronze_config["pipeline"]
        ingester.source_config = bronze_config["source"]
        ingester.transform_config = bronze_config["transform"]
        ingester.target_config = bronze_config["target"]
        ingester.extract = MagicMock(return_value=mock_dataframe)
        ingester.transform = MagicMock(return_value=mock_dataframe)
        ingester.load = MagicMock()
        ingester._log_audit = MagicMock()
        with patch.object(_bronze_mod, "Masker") as MockMasker:
            ingester.run()
        ingester.extract.assert_called_once()
        ingester.transform.assert_called_once_with(mock_dataframe)
        ingester.load.assert_called_once_with(mock_dataframe)
        MockMasker.assert_called_once()
        ingester._log_audit.assert_called_once()
        ingester.audit_logger.log_run_summary.assert_called_once()

    def test_run_skips_when_extract_returns_none(self, patch_base_init, mock_args, bronze_config):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.pipeline_config = bronze_config["pipeline"]
        ingester.source_config = bronze_config["source"]
        ingester.transform_config = bronze_config["transform"]
        ingester.target_config = bronze_config["target"]
        ingester.extract = MagicMock(return_value=None)
        ingester.transform = MagicMock()
        ingester.load = MagicMock()
        ingester.run()
        ingester.extract.assert_called_once()
        ingester.transform.assert_not_called()
        ingester.load.assert_not_called()

    def test_run_logs_error_and_reraises_on_exception(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.pipeline_config = bronze_config["pipeline"]
        ingester.source_config = bronze_config["source"]
        ingester.transform_config = bronze_config["transform"]
        ingester.target_config = bronze_config["target"]
        ingester.extract = MagicMock(return_value=mock_dataframe)
        ingester.transform = MagicMock(side_effect=RuntimeError("boom"))
        ingester._log_audit = MagicMock()
        with pytest.raises(RuntimeError, match="boom"):
            ingester.run()
        ingester.audit_logger.log_error.assert_called_once()
        ingester._log_audit.assert_called_once()
        ingester.audit_logger.log_run_summary.assert_called_once()

    def test_run_always_calls_log_run_summary(self, patch_base_init, mock_args, bronze_config):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.pipeline_config = bronze_config["pipeline"]
        ingester.source_config = bronze_config["source"]
        ingester.transform_config = bronze_config["transform"]
        ingester.target_config = bronze_config["target"]
        ingester.extract = MagicMock(side_effect=Exception("fail"))
        ingester._log_audit = MagicMock()
        with pytest.raises(Exception):
            ingester.run()
        ingester.audit_logger.log_run_summary.assert_called_once()


class TestBronzeLogAudit:

    def test_log_audit_failure_logs_all_files(self, patch_base_init, mock_args, bronze_config):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.target_config = bronze_config["target"]
        file1 = types.SimpleNamespace(name="f1.csv", path="/vol/f1.csv")
        file2 = types.SimpleNamespace(name="f2.csv", path="/vol/f2.csv")
        ingester.files_discovered = [file1, file2]
        ingester._log_audit(df=None, target_table="dev_catalog.schema.bronze_tbl",
                            start_dtm="2026-01-01T00:00:00", failure=True)
        assert ingester.audit_logger.log_file_load.call_count == 2

    def test_log_audit_success_computes_per_file_counts(self, patch_base_init, mock_args, bronze_config, mock_dataframe):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.target_config = bronze_config["target"]
        file1 = types.SimpleNamespace(name="f1.csv", path="/vol/f1.csv")
        ingester.files_discovered = [file1]
        total_row = MagicMock()
        total_row.__getitem__ = lambda self, k: {"file_name": "f1.csv", "records_total": 10}[k]
        mock_dataframe.groupBy.return_value.agg.return_value.collect.return_value = [total_row]
        succeeded_row = MagicMock()
        succeeded_row.__getitem__ = lambda self, k: {"file_name": "f1.csv", "records_succeeded": 10}[k]
        ingester.spark.table.return_value.where.return_value.groupBy.return_value \
            .agg.return_value.collect.return_value = [succeeded_row]
        ingester._log_audit(df=mock_dataframe, target_table="dev_catalog.schema.bronze_tbl",
                            start_dtm="2026-01-01T00:00:00")
        ingester.audit_logger.log_file_load.assert_called_once()

    def test_log_audit_with_no_files_discovered(self, patch_base_init, mock_args, bronze_config):
        ingester = BronzeIngester(mock_args)
        ingester.config = bronze_config
        ingester.target_config = bronze_config["target"]
        ingester.files_discovered = []
        ingester._log_audit(df=None, target_table="dev_catalog.schema.bronze_tbl",
                            start_dtm="2026-01-01T00:00:00", failure=True)
        ingester.audit_logger.log_file_load.assert_not_called()
