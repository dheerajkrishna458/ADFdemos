"""Unit tests for framework.layers.gold.gold_aggregator.GoldAggregator"""

import sys
import pytest
from unittest.mock import MagicMock, patch

_gold_mod = sys.modules["framework.layers.gold.gold_aggregator"]
GoldAggregator = _gold_mod.GoldAggregator


class TestGoldAggregatorInit:
    def test_init_loads_config_sections(self, patch_base_init, mock_args, gold_config):
        a = GoldAggregator(mock_args); a.config = gold_config
        a.pipeline_config = a.config.get("pipeline", {}); a.source_config = a.config.get("source", {})
        a.transform_config = a.config.get("transform", {}); a.target_config = a.config.get("target", {})
        assert a.pipeline_config == {"name": "test_gold_pipeline"}
        assert a.source_config["type"] == "delta_table"
        assert a.target_config["table"] == "catalog.schema.gold_tbl"
    def test_init_has_transform_aggregations(self, patch_base_init, mock_args, gold_config):
        a = GoldAggregator(mock_args); a.config = gold_config; a.transform_config = gold_config["transform"]
        agg = a.transform_config.get("aggregations", {})
        assert agg["group_by"] == ["region"]; assert agg["metrics"][0]["name"] == "total_sales"
    def test_init_sets_args(self, patch_base_init, mock_args):
        assert GoldAggregator(mock_args).args is mock_args

class TestGoldTransform:
    def test_transform_calls_executor(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = GoldAggregator(mock_args); a.config = gold_config; a.transform_config = gold_config["transform"]
        with patch.object(_gold_mod, "TransformationExecutor") as ME:
            ME.apply_transformations.return_value = mock_dataframe
            assert a.transform(mock_dataframe) is mock_dataframe; ME.apply_transformations.assert_called_once()
    def test_transform_returns_dataframe(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = GoldAggregator(mock_args); a.config = gold_config; a.transform_config = gold_config["transform"]
        with patch.object(_gold_mod, "TransformationExecutor") as ME:
            ME.apply_transformations.return_value = mock_dataframe
            assert a.transform(mock_dataframe) is not None
    def test_transform_includes_aggregations_step(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = GoldAggregator(mock_args); a.config = gold_config; a.transform_config = gold_config["transform"]
        with patch.object(_gold_mod, "TransformationExecutor") as ME:
            ME.apply_transformations.return_value = mock_dataframe; a.transform(mock_dataframe)
            assert "aggregations" in ME.apply_transformations.call_args[0][3]
    def test_transform_passes_spark_and_config(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = GoldAggregator(mock_args); a.config = gold_config; a.transform_config = gold_config["transform"]
        with patch.object(_gold_mod, "TransformationExecutor") as ME:
            ME.apply_transformations.return_value = mock_dataframe; a.transform(mock_dataframe)
            ca = ME.apply_transformations.call_args[0]
            assert ca[0] is a.spark; assert ca[2] is a.transform_config

class TestGoldLoad:
    def test_load_append_mode(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = GoldAggregator(mock_args); a.config = gold_config; a.target_config = gold_config["target"]
        a.load(mock_dataframe); assert a.delta_manager.write_df.call_args[0][2] == "append"
    def test_load_overwrite_mode(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        gold_config["target"]["mode"] = "overwrite"
        a = GoldAggregator(mock_args); a.config = gold_config; a.target_config = gold_config["target"]
        a.load(mock_dataframe); assert a.delta_manager.write_df.call_args[0][2] == "overwrite"
    def test_load_merge_mode(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        gold_config["target"]["mode"] = "merge"; gold_config["target"]["merge_condition"] = "tgt.region = src.region"
        a = GoldAggregator(mock_args); a.config = gold_config; a.target_config = gold_config["target"]
        a.load(mock_dataframe); assert a.delta_manager.merge_df.call_args[0][2] == "tgt.region = src.region"
    def test_load_raises_when_no_target_table(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        gold_config["target"]["table"] = None
        a = GoldAggregator(mock_args); a.config = gold_config; a.target_config = gold_config["target"]
        a.env_manager.construct_table_fqn.return_value = None
        with pytest.raises(ValueError, match="No target table configured"): a.load(mock_dataframe)
    def test_load_uses_gold_tbl_properties(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = GoldAggregator(mock_args); a.config = gold_config; a.target_config = gold_config["target"]
        a.load(mock_dataframe); assert a.delta_manager.write_df.call_args[0][3] == a.delta_manager.gold_tbl_properties

class TestGoldRun:
    def _make(self, mock_args, gold_config):
        a = GoldAggregator(mock_args); a.config = gold_config
        for k in ("pipeline","source","transform","target"):
            setattr(a, f"{k}_config", gold_config.get(k, {}))
        return a

    def test_run_happy_path(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = self._make(mock_args, gold_config)
        a.extract = MagicMock(return_value=mock_dataframe); a.transform = MagicMock(return_value=mock_dataframe); a.load = MagicMock()
        with patch.object(_gold_mod, "Masker"): a.run()
        a.extract.assert_called_once(); a.transform.assert_called_once_with(mock_dataframe)
        a.load.assert_called_once_with(mock_dataframe); a.audit_logger.log_run_summary.assert_called_once()
    def test_run_skips_when_extract_returns_none(self, patch_base_init, mock_args, gold_config):
        a = self._make(mock_args, gold_config)
        a.extract = MagicMock(return_value=None); a.transform = MagicMock(); a.load = MagicMock()
        a.run(); a.transform.assert_not_called(); a.load.assert_not_called()
        assert "success" in a.audit_logger.log_run_audit.call_args[0]
    def test_run_logs_error_and_reraises_on_exception(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = self._make(mock_args, gold_config)
        a.extract = MagicMock(return_value=mock_dataframe); a.transform = MagicMock(side_effect=RuntimeError("gold boom"))
        with pytest.raises(RuntimeError, match="gold boom"): a.run()
        a.audit_logger.log_error.assert_called_once()
        assert "failure" in a.audit_logger.log_run_audit.call_args[0]
    def test_run_always_calls_log_run_summary(self, patch_base_init, mock_args, gold_config):
        a = self._make(mock_args, gold_config)
        a.extract = MagicMock(side_effect=Exception("fail"))
        with pytest.raises(Exception): a.run()
        a.audit_logger.log_run_summary.assert_called_once()
    def test_run_masker_receives_correct_args(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = self._make(mock_args, gold_config)
        a.extract = MagicMock(return_value=mock_dataframe); a.transform = MagicMock(return_value=mock_dataframe); a.load = MagicMock()
        with patch.object(_gold_mod, "Masker") as MM:
            a.run(); MM.assert_called_once_with(a.spark, a.args, a.config, a.env_manager)
    def test_run_audit_logged_as_success(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        a = self._make(mock_args, gold_config)
        a.extract = MagicMock(return_value=mock_dataframe); a.transform = MagicMock(return_value=mock_dataframe); a.load = MagicMock()
        with patch.object(_gold_mod, "Masker"): a.run()
        assert "success" in a.audit_logger.log_run_audit.call_args[0]
    def test_run_no_masker_when_extract_returns_none(self, patch_base_init, mock_args, gold_config):
        a = self._make(mock_args, gold_config)
        a.extract = MagicMock(return_value=None); a.transform = MagicMock(); a.load = MagicMock()
        a.run(); a.load.assert_not_called()
