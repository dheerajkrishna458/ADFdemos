"""
Unit tests for framework.layers.silver.silver_refiner.SilverRefiner

Uses patch.object() on the actual loaded module to avoid __import__
walking the real framework package in Databricks.
"""

import pytest
from unittest.mock import MagicMock, patch

from framework.layers.silver.silver_refiner import SilverRefiner


class TestSilverRefinerInit:

    def test_init_loads_config_sections(self, patch_base_init, mock_args, silver_config):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = refiner.config.get("pipeline", {})
        refiner.source_config = refiner.config.get("source", {})
        refiner.transform_config = refiner.config.get("transform", {})
        refiner.target_config = refiner.config.get("target", {})
        assert refiner.pipeline_config == {"name": "test_silver_pipeline"}
        assert refiner.source_config["type"] == "delta_table"
        assert refiner.target_config["mode"] == "overwrite"

    def test_init_sets_args(self, patch_base_init, mock_args):
        refiner = SilverRefiner(mock_args)
        assert refiner.args is mock_args

    def test_init_does_not_have_files_discovered(self, patch_base_init, mock_args):
        refiner = SilverRefiner(mock_args)
        assert refiner.files_discovered == []


class TestSilverTransform:

    def test_transform_calls_executor(self, patch_base_init, mock_args, silver_config, mock_dataframe, silver_module):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.transform_config = silver_config["transform"]
        with patch.object(silver_module, "TransformationExecutor") as MockExecutor:
            MockExecutor.apply_transformations.return_value = mock_dataframe
            result = refiner.transform(mock_dataframe)
            MockExecutor.apply_transformations.assert_called_once()
            assert result is mock_dataframe

    def test_transform_returns_dataframe(self, patch_base_init, mock_args, silver_config, mock_dataframe, silver_module):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.transform_config = silver_config["transform"]
        with patch.object(silver_module, "TransformationExecutor") as MockExecutor:
            MockExecutor.apply_transformations.return_value = mock_dataframe
            result = refiner.transform(mock_dataframe)
            assert result is not None

    def test_transform_passes_spark_and_config(self, patch_base_init, mock_args, silver_config, mock_dataframe, silver_module):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.transform_config = silver_config["transform"]
        with patch.object(silver_module, "TransformationExecutor") as MockExecutor:
            MockExecutor.apply_transformations.return_value = mock_dataframe
            refiner.transform(mock_dataframe)
            call_args = MockExecutor.apply_transformations.call_args[0]
            assert call_args[0] is refiner.spark
            assert call_args[2] is refiner.transform_config


class TestSilverLoad:

    def test_load_overwrite_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]
        refiner.load(mock_dataframe)
        refiner.delta_manager.write_df.assert_called_once()
        assert refiner.delta_manager.write_df.call_args[0][2] == "overwrite"

    def test_load_append_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args)
        silver_config["target"]["mode"] = "append"
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]
        refiner.load(mock_dataframe)
        assert refiner.delta_manager.write_df.call_args[0][2] == "append"

    def test_load_merge_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args)
        silver_config["target"]["mode"] = "merge"
        silver_config["target"]["merge_condition"] = "tgt.id = src.id"
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]
        refiner.load(mock_dataframe)
        refiner.delta_manager.merge_df.assert_called_once()
        assert refiner.delta_manager.merge_df.call_args[0][2] == "tgt.id = src.id"

    def test_load_raises_when_no_target_table(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args)
        silver_config["target"]["table"] = None
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]
        refiner.env_manager.construct_table_fqn.return_value = None
        with pytest.raises(ValueError, match="No target table configured"):
            refiner.load(mock_dataframe)

    def test_load_uses_silver_tbl_properties(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]
        refiner.load(mock_dataframe)
        assert refiner.delta_manager.write_df.call_args[0][3] == refiner.delta_manager.silver_tbl_properties


class TestSilverRun:

    def test_run_happy_path(self, patch_base_init, mock_args, silver_config, mock_dataframe, silver_module):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]
        refiner.extract = MagicMock(return_value=mock_dataframe)
        refiner.transform = MagicMock(return_value=mock_dataframe)
        refiner.load = MagicMock()

        with patch.object(silver_module, "DataQualityCheck") as MockDQ, \
             patch.object(silver_module, "Masker"):
            dq_instance = MagicMock()
            dq_instance.apply_checks.return_value = mock_dataframe
            MockDQ.return_value = dq_instance
            refiner.run()

        refiner.extract.assert_called_once()
        refiner.transform.assert_called_once_with(mock_dataframe)
        dq_instance.apply_checks.assert_called_once_with(mock_dataframe)
        refiner.load.assert_called_once_with(mock_dataframe)
        refiner.audit_logger.log_run_audit.assert_called_once()
        refiner.audit_logger.log_run_summary.assert_called_once()

    def test_run_skips_when_extract_returns_none(self, patch_base_init, mock_args, silver_config):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]
        refiner.extract = MagicMock(return_value=None)
        refiner.transform = MagicMock()
        refiner.load = MagicMock()
        refiner.run()
        refiner.extract.assert_called_once()
        refiner.transform.assert_not_called()
        refiner.load.assert_not_called()
        refiner.audit_logger.log_run_audit.assert_called_once()
        assert "success" in refiner.audit_logger.log_run_audit.call_args[0]

    def test_run_logs_error_and_reraises_on_exception(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]
        refiner.extract = MagicMock(return_value=mock_dataframe)
        refiner.transform = MagicMock(side_effect=RuntimeError("silver boom"))
        with pytest.raises(RuntimeError, match="silver boom"):
            refiner.run()
        refiner.audit_logger.log_error.assert_called_once()
        assert "failure" in refiner.audit_logger.log_run_audit.call_args[0]
        refiner.audit_logger.log_run_summary.assert_called_once()

    def test_run_always_calls_log_run_summary(self, patch_base_init, mock_args, silver_config):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]
        refiner.extract = MagicMock(side_effect=Exception("fail"))
        with pytest.raises(Exception):
            refiner.run()
        refiner.audit_logger.log_run_summary.assert_called_once()

    def test_run_invokes_data_quality_check(self, patch_base_init, mock_args, silver_config, mock_dataframe, silver_module):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]
        refiner.extract = MagicMock(return_value=mock_dataframe)
        refiner.transform = MagicMock(return_value=mock_dataframe)
        refiner.load = MagicMock()

        with patch.object(silver_module, "DataQualityCheck") as MockDQ, \
             patch.object(silver_module, "Masker"):
            dq_instance = MagicMock()
            dq_instance.apply_checks.return_value = mock_dataframe
            MockDQ.return_value = dq_instance
            refiner.run()
            MockDQ.assert_called_with(
                refiner.spark, refiner.config, refiner.env_manager,
                refiner.audit_logger, refiner.delta_manager
            )
            dq_instance.apply_checks.assert_called_once_with(mock_dataframe)

    def test_run_passes_dq_result_to_load(self, patch_base_init, mock_args, silver_config, mock_dataframe, silver_module):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]
        dq_output_df = MagicMock(name="DQ_Output_DF")
        refiner.extract = MagicMock(return_value=mock_dataframe)
        refiner.transform = MagicMock(return_value=mock_dataframe)
        refiner.load = MagicMock()

        with patch.object(silver_module, "DataQualityCheck") as MockDQ, \
             patch.object(silver_module, "Masker"):
            dq_instance = MagicMock()
            dq_instance.apply_checks.return_value = dq_output_df
            MockDQ.return_value = dq_instance
            refiner.run()

        refiner.load.assert_called_once_with(dq_output_df)
