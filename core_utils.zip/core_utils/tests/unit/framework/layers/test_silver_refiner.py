"""Unit tests for framework.layers.silver.silver_refiner.SilverRefiner"""

import sys
import pytest
from unittest.mock import MagicMock, patch

_silver_mod = sys.modules["framework.layers.silver.silver_refiner"]
SilverRefiner = _silver_mod.SilverRefiner


class TestSilverRefinerInit:
    def test_init_loads_config_sections(self, patch_base_init, mock_args, silver_config):
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = refiner.config.get("pipeline", {})
        refiner.source_config = refiner.config.get("source", {})
        refiner.transform_config = refiner.config.get("transform", {})
        refiner.target_config = refiner.config.get("target", {})
        assert refiner.pipeline_config == {"name": "test_silver_pipeline"}
        assert refiner.source_config["type"] == "delta_table"
        assert refiner.target_config["mode"] == "overwrite"
    def test_init_sets_args(self, patch_base_init, mock_args):
        assert SilverRefiner(mock_args).args is mock_args
    def test_init_does_not_have_files_discovered(self, patch_base_init, mock_args):
        assert SilverRefiner(mock_args).files_discovered == []

class TestSilverTransform:
    def test_transform_calls_executor(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args); refiner.config = silver_config; refiner.transform_config = silver_config["transform"]
        with patch.object(_silver_mod, "TransformationExecutor") as ME:
            ME.apply_transformations.return_value = mock_dataframe
            assert refiner.transform(mock_dataframe) is mock_dataframe
            ME.apply_transformations.assert_called_once()
    def test_transform_returns_dataframe(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args); refiner.config = silver_config; refiner.transform_config = silver_config["transform"]
        with patch.object(_silver_mod, "TransformationExecutor") as ME:
            ME.apply_transformations.return_value = mock_dataframe
            assert refiner.transform(mock_dataframe) is not None
    def test_transform_passes_spark_and_config(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        refiner = SilverRefiner(mock_args); refiner.config = silver_config; refiner.transform_config = silver_config["transform"]
        with patch.object(_silver_mod, "TransformationExecutor") as ME:
            ME.apply_transformations.return_value = mock_dataframe
            refiner.transform(mock_dataframe)
            ca = ME.apply_transformations.call_args[0]
            assert ca[0] is refiner.spark; assert ca[2] is refiner.transform_config

class TestSilverLoad:
    def test_load_overwrite_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        r = SilverRefiner(mock_args); r.config = silver_config; r.target_config = silver_config["target"]
        r.load(mock_dataframe); assert r.delta_manager.write_df.call_args[0][2] == "overwrite"
    def test_load_append_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        silver_config["target"]["mode"] = "append"
        r = SilverRefiner(mock_args); r.config = silver_config; r.target_config = silver_config["target"]
        r.load(mock_dataframe); assert r.delta_manager.write_df.call_args[0][2] == "append"
    def test_load_merge_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        silver_config["target"]["mode"] = "merge"; silver_config["target"]["merge_condition"] = "tgt.id = src.id"
        r = SilverRefiner(mock_args); r.config = silver_config; r.target_config = silver_config["target"]
        r.load(mock_dataframe); assert r.delta_manager.merge_df.call_args[0][2] == "tgt.id = src.id"
    def test_load_raises_when_no_target_table(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        silver_config["target"]["table"] = None
        r = SilverRefiner(mock_args); r.config = silver_config; r.target_config = silver_config["target"]
        r.env_manager.construct_table_fqn.return_value = None
        with pytest.raises(ValueError, match="No target table configured"): r.load(mock_dataframe)
    def test_load_uses_silver_tbl_properties(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        r = SilverRefiner(mock_args); r.config = silver_config; r.target_config = silver_config["target"]
        r.load(mock_dataframe); assert r.delta_manager.write_df.call_args[0][3] == r.delta_manager.silver_tbl_properties

class TestSilverRun:
    def _make(self, mock_args, silver_config):
        r = SilverRefiner(mock_args); r.config = silver_config
        for k in ("pipeline","source","transform","target"):
            setattr(r, f"{k}_config", silver_config.get(k, {}))
        return r

    def test_run_happy_path(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        r = self._make(mock_args, silver_config)
        r.extract = MagicMock(return_value=mock_dataframe); r.transform = MagicMock(return_value=mock_dataframe); r.load = MagicMock()
        with patch.object(_silver_mod, "DataQualityCheck") as MDQ, patch.object(_silver_mod, "Masker"):
            dq = MagicMock(); dq.apply_checks.return_value = mock_dataframe; MDQ.return_value = dq
            r.run()
        r.extract.assert_called_once(); r.transform.assert_called_once_with(mock_dataframe)
        dq.apply_checks.assert_called_once_with(mock_dataframe); r.load.assert_called_once_with(mock_dataframe)
        r.audit_logger.log_run_audit.assert_called_once(); r.audit_logger.log_run_summary.assert_called_once()

    def test_run_skips_when_extract_returns_none(self, patch_base_init, mock_args, silver_config):
        r = self._make(mock_args, silver_config)
        r.extract = MagicMock(return_value=None); r.transform = MagicMock(); r.load = MagicMock()
        r.run(); r.transform.assert_not_called(); r.load.assert_not_called()
        assert "success" in r.audit_logger.log_run_audit.call_args[0]

    def test_run_logs_error_and_reraises_on_exception(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        r = self._make(mock_args, silver_config)
        r.extract = MagicMock(return_value=mock_dataframe); r.transform = MagicMock(side_effect=RuntimeError("silver boom"))
        with pytest.raises(RuntimeError, match="silver boom"): r.run()
        r.audit_logger.log_error.assert_called_once()
        assert "failure" in r.audit_logger.log_run_audit.call_args[0]

    def test_run_always_calls_log_run_summary(self, patch_base_init, mock_args, silver_config):
        r = self._make(mock_args, silver_config)
        r.extract = MagicMock(side_effect=Exception("fail"))
        with pytest.raises(Exception): r.run()
        r.audit_logger.log_run_summary.assert_called_once()

    def test_run_invokes_data_quality_check(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        r = self._make(mock_args, silver_config)
        r.extract = MagicMock(return_value=mock_dataframe); r.transform = MagicMock(return_value=mock_dataframe); r.load = MagicMock()
        with patch.object(_silver_mod, "DataQualityCheck") as MDQ, patch.object(_silver_mod, "Masker"):
            dq = MagicMock(); dq.apply_checks.return_value = mock_dataframe; MDQ.return_value = dq
            r.run()
            MDQ.assert_called_with(r.spark, r.config, r.env_manager, r.audit_logger, r.delta_manager)

    def test_run_passes_dq_result_to_load(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        r = self._make(mock_args, silver_config)
        dq_df = MagicMock(name="DQ_DF")
        r.extract = MagicMock(return_value=mock_dataframe); r.transform = MagicMock(return_value=mock_dataframe); r.load = MagicMock()
        with patch.object(_silver_mod, "DataQualityCheck") as MDQ, patch.object(_silver_mod, "Masker"):
            dq = MagicMock(); dq.apply_checks.return_value = dq_df; MDQ.return_value = dq
            r.run()
        r.load.assert_called_once_with(dq_df)
