import pytest
from unittest.mock import Mock, patch
from framework.core.base import MedallionBase

from framework.modules.io.reader import (
    BaseFileIngester,
    CSVFileIngester,
    EBCDICFileIngester,
)

class MedallionTest(MedallionBase):
    def transform(self, df):
        return df

    def load(self, df):
        pass

    def run(self):
        pass

@pytest.fixture
def mock_dependencies():
    """Mock framework dependencies for isolated MedallionBase tests."""
    with patch("framework.core.base.SessionManager.get_session") as mock_get_session, \
         patch("framework.core.base.EnvironmentManager") as mock_env_manager, \
         patch("framework.core.base.AuditLogger") as mock_audit_logger, \
         patch("framework.core.base.DeltaManager") as mock_delta_manager, \
         patch("framework.core.base.ConfigManager") as mock_config_manager, \
         patch("framework.modules.logging.log_manager.LoggingConfigurator") as mock_setup_logging, \
         patch("framework.core.base.YamlTelemetryLogger") as mock_yaml_logger:

        # Spark mock
        spark = Mock()
        mock_get_session.return_value = spark

        # EnvironmentManager mock
        env_instance = Mock()
        env_instance.get_code_log_table_fqn.return_value = None
        mock_env_manager.return_value = env_instance

        # ConfigManager mock
        config_instance = Mock()
        config_instance.config = {"source": {"type": "file"}}
        mock_config_manager.return_value = config_instance

        # YAML logger mock
        yaml_instance = Mock()
        mock_yaml_logger.return_value = yaml_instance

        yield {
            "spark": spark,
            "env": env_instance,
            "config": config_instance,
        }


def test_get_ingestor_csv(mock_dependencies):
    """Validate CSV format resolves to CSVFileIngester."""
    medallion = MedallionTest(Mock())

    ingestor = medallion._get_ingestor({"format": "csv"})

    assert isinstance(ingestor, CSVFileIngester)


def test_get_ingestor_cobol(mock_dependencies):
    """Validate COBOL format resolves to EBCDICFileIngester."""
    medallion = MedallionTest(Mock())

    ingestor = medallion._get_ingestor({"format": "cobol"})

    assert isinstance(ingestor, EBCDICFileIngester)


def test_get_ingestor_default(mock_dependencies):
    """Validate unknown non-special format falls back to BaseFileIngester."""
    medallion = MedallionTest(Mock())

    ingestor = medallion._get_ingestor({"format": "parquet"})

    assert isinstance(ingestor, BaseFileIngester)

def test_extract_file_source(mock_dependencies):
    """Validate file source extraction returns dataframe and discovered files."""
    medallion = MedallionTest(Mock())

    medallion.source_config = {
        "type": "file",
        "properties": {"format": "csv"}
    }

    mock_df = Mock()

    with patch.object(medallion, "_get_ingestor") as mock_get_ingestor:
        mock_ingestor = Mock()
        mock_ingestor.read_df.return_value = mock_df
        mock_ingestor.discovered_files = ["file1.csv", "file2.csv"]
        mock_get_ingestor.return_value = mock_ingestor

        df = medallion.extract()

    assert df == mock_df
    assert medallion.files_discovered == ["file1.csv", "file2.csv"]


def test_extract_delta_table_source(mock_dependencies):
    """Validate delta_table source extraction returns ingested dataframe."""
    medallion = MedallionTest(Mock())

    medallion.source_config = {
        "type": "delta_table",
        "properties": {"table": "my_delta_table"}
    }

    mock_df = Mock()

    with patch("framework.core.base.DeltaTableIngester") as mock_delta_ingester:
        mock_delta_ingester.return_value.read_df.return_value = mock_df

        df = medallion.extract()

    assert df == mock_df


def test_extract_unsupported_source_type(mock_dependencies):
    """Validate unsupported source types raise a ValueError."""
    medallion = MedallionTest(Mock())

    medallion.source_config = {"type": "unknown"}

    with pytest.raises(ValueError, match="Unsupported source type"):
        medallion.extract()