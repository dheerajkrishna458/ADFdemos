import sys
from framework.core.arg_parser import ArgParser


def test_parse_required_and_default_values(monkeypatch):
    """Validate parser populates required args and framework defaults."""
    monkeypatch.setattr( # monkeypatch sys.argv to simulate CLI input
        sys,
        "argv",
        [
            "prog", # first argument is the file name, which argparse ignores
            "--config_file_name", "sample_config.yml",
            "--config_catalog", "resource_sandbox",
            "--config_directory_path", "/tmp/configs",
            "--email_id", "user@example.com",
        ],
    )

    args = ArgParser.parse(entry_point="run_bronze", layer="bronze")

    assert args.config_file_name == "sample_config.yml"
    assert args.config_catalog == "resource_sandbox"
    assert args.config_directory_path == "/tmp/configs"
    assert args.email_id == "user@example.com"
    assert args.entry_point == "run_bronze"
    assert args.layer == "bronze"
    assert args.databricks_job_id == "test_job_id"
    assert args.databricks_run_id == "test_run_id"
    assert args.correlation_id == "test_correlation_id"
    assert args.test_catalog == "resource_sandbox"
    assert args.dry_run == "false"


def test_parse_required_and_override_default_values(monkeypatch):
    """Validate parser accepts explicit CLI overrides for default fields."""
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "prog",
            "--config_file_name", "sample_config.yml",
            "--config_catalog", "resource_sandbox",
            "--config_directory_path", "/tmp/configs",
            "--email_id", "user@example.com",
            "--entry_point", "run_gold",
            "--layer", "gold",
            "--databricks_job_id", "job-123",
            "--databricks_run_id", "run-456",
            "--correlation_id", "corr-789"
        ],
    )

    args = ArgParser.parse(entry_point="run_bronze", layer="bronze")

    assert args.config_file_name == "sample_config.yml"
    assert args.config_catalog == "resource_sandbox"
    assert args.config_directory_path == "/tmp/configs"
    assert args.email_id == "user@example.com"
    assert args.entry_point == "run_gold"
    assert args.layer == "gold"
    assert args.databricks_job_id == "job-123"
    assert args.databricks_run_id == "run-456"
    assert args.correlation_id == "corr-789"    
