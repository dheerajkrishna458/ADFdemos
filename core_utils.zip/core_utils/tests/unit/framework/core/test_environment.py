import pytest
from unittest.mock import Mock

from framework.core.environment import EnvironmentManager
from framework.core.enum import Environment

@pytest.fixture
def mock_spark():
    """Mock Spark session for testing."""
    spark = Mock()

    # Default workspace URL is DEV
    spark.conf.get.return_value = "adb-5637650859544783.3.azuredatabricks.net"

    # Mock spark.table() chain
    df = Mock()
    df.filter.return_value = df
    df.select.return_value = df
    df.limit.return_value = df
    df.first.return_value = None

    spark.table.return_value = df
    return spark

@pytest.fixture
def mock_args():
    """Mock arguments for testing."""
    args = Mock()
    args.test_schema = None
    args.test_catalog = None
    return args

def test_env_dev(mock_spark, mock_args):
    """Test DEV environment detection."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.env == Environment.DEV
    assert env_mgr.env_prefix == "dev_"

def test_env_beta(mock_spark, mock_args):
    """Test BETA environment detection."""
    mock_spark.conf.get.return_value = "adb-4300184777753314.14.azuredatabricks.net"
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.env == Environment.BETA
    assert env_mgr.env_prefix == "beta_"

def test_env_prod(mock_spark, mock_args):
    """Test PROD environment detection."""
    mock_spark.conf.get.return_value = "adb-4725979452643860.0.azuredatabricks.net"
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.env == Environment.PROD
    assert env_mgr.env_prefix == "prod_"

def test_env_unknown_defaults_to_dev(mock_spark, mock_args):
    """Test unknown environment defaults to DEV."""
    mock_spark.conf.get.return_value = "unknown" # should default to DEV
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.env == Environment.DEV

def test_workspace_name_found(mock_spark, mock_args):
    """Test workspace name extraction."""
    mock_spark.table.return_value.first.return_value = {
        "workspace_name": "dev_workspace"
    }
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.workspace_name == "dev_workspace"

# Sandbox behavior tests
def test_sandbox_set_in_dev(mock_spark, mock_args):
    """Test sandbox is set in DEV environment."""
    mock_args.test_schema = "test_schema"
    mock_args.test_catalog = "sandbox_catalog"

    env_mgr = EnvironmentManager(mock_spark, mock_args)

    assert env_mgr.catalog == "sandbox_catalog"
    assert env_mgr.schema == "test_schema"

def test_sandbox_not_set_when_schema_none(mock_spark, mock_args):
    """Test sandbox not set when schema is None."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.catalog is None
    assert env_mgr.schema is None

# Catalog / schema / table name construction tests
def test_construct_volume_catalog_name(mock_spark, mock_args):
    """Test volume catalog name construction."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.construct_volume_catalog_name("deltalake") == "dev_deltalake"

def test_construct_catalog_name_without_sandbox(mock_spark, mock_args):
    """Test catalog name construction without sandbox."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.construct_catalog_name("deltalake") == "dev_deltalake"

def test_construct_catalog_name_with_sandbox(mock_spark, mock_args):
    """Test catalog name construction with sandbox."""
    mock_args.test_schema = "test_schema"
    mock_args.test_catalog = "resource_sandbox"

    env_mgr = EnvironmentManager(mock_spark, mock_args)

    assert env_mgr.construct_catalog_name("deltalake") == "resource_sandbox"

def test_construct_schema_name_without_sandbox(mock_spark, mock_args):
    """Test schema name construction without sandbox."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.construct_schema_name("sample_schema") == "sample_schema"

def test_construct_schema_name_with_sandbox(mock_spark, mock_args):
    """Test schema name construction with sandbox."""
    mock_args.test_schema = "test_schema"
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.construct_schema_name("sample_schema") == "test_schema"

def test_construct_table_name_without_sandbox(mock_spark, mock_args):
    """Test table name construction without sandbox."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.construct_table_name("sample_schema", "sample_table") == "sample_table"

def test_construct_table_name_with_sandbox(mock_spark, mock_args):
    """Test table name construction with sandbox."""
    mock_args.test_schema = "test_schema"
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.construct_table_name("sample_schema", "sample_table") == "sample_schema_sample_table"

# Source path
def test_construct_source_folder_path(mock_spark, mock_args):
    """Test source folder path construction."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.construct_source_folder_path("/tmp/data") == "/Volumes/dev_deltalake/raw/tmp/data"

# Audit & YAML FQNs tests
def test_audit_fqns_without_sandbox(mock_spark, mock_args):
    """Test audit FQNs without sandbox."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)

    assert env_mgr.get_error_logs_fqn() == "dev_deltalake_audit.audit_logs.error_logs"
    assert env_mgr.get_run_load_history_fqn() == "dev_deltalake_audit.audit_logs.run_load_history"
    assert env_mgr.get_code_log_table_fqn() == "dev_deltalake_audit.audit_logs.code_logs"
    assert env_mgr.get_yaml_load_history_fqn() == "dev_deltalake_audit.audit_logs.yaml_load_history"

def test_audit_fqns_with_sandbox(mock_spark, mock_args):
    """Test audit FQNs with sandbox."""
    mock_args.test_schema = "test_schema"
    mock_args.test_catalog = "test_catalog"

    env_mgr = EnvironmentManager(mock_spark, mock_args)

    assert env_mgr.get_yaml_load_history_fqn() == "test_catalog.test_schema.yaml_load_history"
    assert env_mgr.get_code_log_table_fqn() == "test_catalog.test_schema.code_logs"
    assert env_mgr.get_run_load_history_fqn() == "test_catalog.test_schema.run_load_history"
    assert env_mgr.get_error_logs_fqn() == "test_catalog.test_schema.error_logs"    

def test_data_quality_fqns_without_sandbox(mock_spark, mock_args):
    """Test data quality FQNs without sandbox."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)

    assert env_mgr.get_data_quality_exceptions_fqn() == "dev_deltalake_audit.audit_logs.data_quality_exceptions"
    assert env_mgr.get_data_quality_summary_fqn() == "dev_deltalake_audit.audit_logs.data_quality_summary"

def test_data_quality_fqns_with_sandbox(mock_spark, mock_args):
    """Test data quality FQNs with sandbox."""
    mock_args.test_schema = "test_schema"
    mock_args.test_catalog = "test_catalog"

    env_mgr = EnvironmentManager(mock_spark, mock_args)

    assert (
        env_mgr.get_data_quality_exceptions_fqn()
        == "test_catalog.test_schema.data_quality_exceptions"
    )
    assert (
        env_mgr.get_data_quality_summary_fqn()
        == "test_catalog.test_schema.data_quality_summary"
    )

# Table FQN tests
def test_parse_cleaned_table_path_valid(mock_spark, mock_args):
    """Test valid cleaned table path parsing."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert env_mgr.parse_cleaned_table_path("catalog.schema.table") == ("catalog", "schema", "table",)

def test_parse_cleaned_table_path_invalid(mock_spark, mock_args):
    """Test invalid cleaned table path parsing."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    with pytest.raises(ValueError):
        env_mgr.parse_cleaned_table_path("schema.table") # no catalog specified

def test_construct_table_fqn(mock_spark, mock_args):
    """Test table FQN construction."""
    env_mgr = EnvironmentManager(mock_spark, mock_args)
    assert (
        env_mgr.construct_table_fqn("deltalake.schema.table")
        == "dev_deltalake.schema.table"
    )

def test_get_masking_function_fqn(mock_spark, mock_args):
    """Test masking function FQN construction."""
    mock_spark.conf.get.return_value = "adb-4300184777753314.14.azuredatabricks.net"

    env_mgr = EnvironmentManager(mock_spark, mock_args)

    assert env_mgr.get_masking_function_fqn("mask_table") == "beta_protect.masking.mask_table"