from pathlib import Path
import pytest
from unittest.mock import Mock, patch, mock_open
from framework.core.config import ConfigManager


@pytest.fixture
def mock_args():
    """Mock command line arguments."""
    args = Mock()
    args.config_directory_path = "/test/config/path"
    args.config_catalog = "resource_sandbox"
    args.config_file_name = "config.yml"
    args.layer = "bronze"
    return args


def valid_bronze_config():
    return {
        "pipeline": {
            "name": "test_pipeline",
            "layer": "bronze",
        },
        "source": {
            "type": "file",
            "properties": {
                "format": "csv",
                "extension": ".csv",
                "source_path": "/input/data",
            },
        },
        "target": {
            "mode": "append",
            "format": "delta",
            "table": "catalog.schema.table",
        },
    }


def valid_silver_config():
    return {
        "pipeline": {
            "name": "test_pipeline",
            "layer": "silver",
        },
        "source": {
            "type": "delta_table",
            "properties": {
                "format": "delta",
                "table": "catalog.schema.source_table",
            },
        },
        "target": {
            "mode": "overwrite",
            "format": "delta",
            "table": "catalog.schema.target_table",
        },
    }


def test_read_config(mock_args):
    """Test reading config file."""
    test_config = valid_bronze_config()
    with patch("builtins.open", mock_open()), patch("yaml.safe_load", return_value=test_config):
        cm = ConfigManager(mock_args)
        result = cm.read_config("/test/config.yml")
    assert result == test_config


def test_load_config_success(mock_args):
    """Test successful config load."""
    test_config = valid_bronze_config()
    with patch("os.path.exists", return_value=True), \
         patch("builtins.open", mock_open()), \
         patch("yaml.safe_load", return_value=test_config):
        cm = ConfigManager(mock_args)
        cm.load_config()
        assert cm.config == test_config
        assert cm.config_file_path.endswith("config.yml")


def test_missing_top_level_key(mock_args):
    """Test missing top-level key in config."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    del config["source"]
    with pytest.raises(ValueError, match="Missing mandatory top-level key"):
        cm.validate_yaml_config(config)


def test_missing_pipeline_key(mock_args):
    """Test missing pipeline key in config."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    del config["pipeline"]["layer"]
    with pytest.raises(ValueError, match="Missing pipeline.layer"):
        cm.validate_yaml_config(config)


def test_missing_target_key(mock_args):
    """Test missing target key in config."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    del config["target"]["table"]
    with pytest.raises(ValueError, match="Missing target.table"):
        cm.validate_yaml_config(config)


def test_invalid_masking_rule(mock_args):
    """Test invalid masking rule in config."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    config["security"] = {"masking": [{"column": "ssn"}]}
    with pytest.raises(ValueError, match="Invalid masking rule"):
        cm.validate_yaml_config(config)


def test_bronze_invalid_source_type(mock_args):
    """Test invalid bronze source type."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    config["source"]["type"] = "delta_table"
    with pytest.raises(ValueError, match="Bronze source.type must be 'file'"):
        cm.validate_yaml_config(config)


def test_bronze_missing_properties(mock_args):
    """Test missing properties in bronze source."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    del config["source"]["properties"]
    with pytest.raises(ValueError, match="source.properties is mandatory"):
        cm.validate_yaml_config(config)


def test_bronze_missing_required_property(mock_args):
    """Test missing required property in bronze source."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    del config["source"]["properties"]["format"]
    with pytest.raises(ValueError, match="Missing source.properties.format"):
        cm.validate_yaml_config(config)


def test_bronze_invalid_format(mock_args):
    """Test invalid format in bronze source."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    config["source"]["properties"]["format"] = "xml"
    with pytest.raises(ValueError, match="source.properties.format must be one of"):
        cm.validate_yaml_config(config)


def test_silver_invalid_source_type(mock_args):
    """Test invalid silver source type."""
    cm = ConfigManager(mock_args)
    config = valid_silver_config()
    config["source"]["type"] = "file"
    with pytest.raises(ValueError, match="silver source.type must be 'delta_table'"):
        cm.validate_yaml_config(config)


def test_silver_missing_table(mock_args):
    """Test missing table in silver source properties."""
    cm = ConfigManager(mock_args)
    config = valid_silver_config()
    del config["source"]["properties"]["table"]
    with pytest.raises(ValueError, match="Missing source.properties.table"):
        cm.validate_yaml_config(config)


def test_invalid_target_mode(mock_args):
    """Test invalid target mode."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    config["target"]["mode"] = "delete"
    with pytest.raises(ValueError, match="target.mode must be one of"):
        cm.validate_yaml_config(config)


def test_invalid_target_table_fqn(mock_args):
    """Test invalid target table FQN."""
    cm = ConfigManager(mock_args)
    config = valid_bronze_config()
    config["target"]["table"] = "invalid_table"
    with pytest.raises(ValueError, match="Invalid table format"):
        cm.validate_yaml_config(config)


def test_validate_table_fqn_valid(mock_args):
    """Test valid table FQN."""
    cm = ConfigManager(mock_args)
    assert cm._validate_table_fqn("catalog.schema.table") is None # If no exception is raised, the test passes


def test_validate_table_fqn_invalid(mock_args):
    """Test invalid table FQN."""
    cm = ConfigManager(mock_args)
    with pytest.raises(ValueError, match="Expected catalog.schema.table"):
        cm._validate_table_fqn("schema.table")


def test_validate_all_deltalake_configs(mock_args, pytestconfig):
    """Validate all YAML configs under deltalake_dabs/configs/deltalake."""
    cm = ConfigManager(mock_args)

    repo_root = Path(pytestconfig.rootpath).resolve()
    configs_root = repo_root / "deltalake_dabs" / "configs"

    yaml_files = list(configs_root.rglob("*.yml"))

    assert yaml_files, f"No YAML configs found under {configs_root}"

    failures = []
    for yaml_file in yaml_files:
        try:
            config = cm.read_config(str(yaml_file))
            cm.validate_yaml_config(config)
        except Exception as exc:
            failures.append(f"{yaml_file.relative_to(repo_root)} -> {exc}")

    assert not failures, "Config validation failed:\n" + "\n".join(failures)