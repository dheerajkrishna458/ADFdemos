import pytest
from framework.core.enum import (
    AuditColumns,
    Environment,
    LoadStageName,
    LoadStatus,
    LoadTypeName,
    OperationType,
    Layer
)


# Environment Enum
def test_environment_enum_values():
    assert Environment.DEV.value == "dev"
    assert Environment.BETA.value == "beta"
    assert Environment.PROD.value == "prod"


# Layer Enum
def test_layer_enum_values():
    assert Layer.BRONZE.value == "bronze"
    assert Layer.SILVER.value == "silver"
    assert Layer.GOLD.value == "gold"


# LoadStatus Enum
def test_load_status_enum_values():
    assert LoadStatus.SUCCESS.value == "Success"
    assert LoadStatus.FAILURE.value == "Failed"


# LoadStageName Enum
def test_load_stage_name_enum_values():
    assert LoadStageName.RAW_TO_BRONZE.value == "RawToBronze"
    assert LoadStageName.BRONZE_TO_SILVER.value == "BronzeToSilver"
    assert LoadStageName.SILVER_TO_GOLD.value == "SilverToGold"
    assert LoadStageName.UNKNOWN.value == "UnknownStage"


def test_load_stage_name_from_layer_valid():
    assert LoadStageName.from_layer("bronze") == LoadStageName.RAW_TO_BRONZE
    assert LoadStageName.from_layer("silver") == LoadStageName.BRONZE_TO_SILVER
    assert LoadStageName.from_layer("gold") == LoadStageName.SILVER_TO_GOLD


def test_load_stage_name_from_layer_unknown():
    assert LoadStageName.from_layer("platinum") == LoadStageName.UNKNOWN
    assert LoadStageName.from_layer("") == LoadStageName.UNKNOWN


# LoadTypeName Enum
def test_load_type_name_enum_values():
    assert LoadTypeName.PIPELINE.value == "Pipeline"
    assert LoadTypeName.MANUAL.value == "Manual"


# OperationType Enum
def test_operation_type_enum_values():
    assert OperationType.APPEND.value == "APPEND"
    assert OperationType.OVERWRITE.value == "OVERWRITE"
    assert OperationType.MERGE.value == "MERGE"


def test_operation_type_from_mode_valid():
    assert OperationType.from_mode("append") == OperationType.APPEND
    assert OperationType.from_mode("overwrite") == OperationType.OVERWRITE
    assert OperationType.from_mode("merge") == OperationType.MERGE


def test_audit_columns_values_contains_all_members():
    expected = {
        "file_name",
        "correlation_id",
        "databricks_job_id",
        "databricks_run_id",
        "load_create_user_id",
        "load_update_user_id",
        "load_create_dtm",
        "load_update_dtm",
    }
    assert AuditColumns.values() == expected