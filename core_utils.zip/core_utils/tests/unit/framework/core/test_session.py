import pytest
import types
from unittest.mock import Mock, patch
from framework.core.session import SessionManager


def test_get_session_app_name():
    """
    Test that SessionManager.get_session returns the mocked SparkSession instance
    and that appName is called with the correct argument.
    """
    mock_spark = Mock()
    mock_builder = Mock()
    mock_builder.appName.return_value.getOrCreate.return_value = mock_spark

    with patch("framework.core.session.SparkSession.builder", mock_builder):
        result = SessionManager.get_session("TestSparkApp")

    # Ensure the mocked SparkSession instance is returned (identity check, not equality)
    assert result is mock_spark 
    mock_builder.appName.assert_called_once_with("TestSparkApp")


def test_get_dbutils_success():
    """
    Test that SessionManager.get_dbutils returns the mocked DBUtils instance
    when a mock pyspark.dbutils module is injected.
    """
    mock_spark = Mock()
    mock_dbutils = Mock()
    dbutils_module = types.ModuleType("pyspark.dbutils")
    dbutils_module.DBUtils = Mock(return_value=mock_dbutils)

    # Inject a mock pyspark.dbutils module so local import inside get_dbutils resolves.
    with patch.dict("sys.modules", {"pyspark.dbutils": dbutils_module}):
        result = SessionManager.get_dbutils(mock_spark)

    assert result == mock_dbutils