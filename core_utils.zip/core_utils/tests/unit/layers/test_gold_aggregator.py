"""
Unit tests for framework.layers.gold.gold_aggregator.GoldAggregator

Uses patch_base_init fixture from conftest.py — all Spark/Databricks
dependencies are mocked via sys.modules patching.

NOTE: Written against the zip-packaged source which uses:
  - TransformationExecutor.apply_transformations()
  - Config keys: 'pipeline', 'target'
  - log_run_audit(df, config, event_type, start_dtm)
"""

import pytest
from unittest.mock import MagicMock

from framework.layers.gold.gold_aggregator import GoldAggregator


# ===================================================================
# Construction / Initialisation
# ===================================================================

class TestGoldAggregatorInit:
    """Tests for __init__ and attribute setup."""

    def test_init_loads_config_sections(self, patch_base_init, mock_args, gold_config):
        """pipeline, source, transform, target configs are loaded."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.pipeline_config = aggregator.config.get("pipeline", {})
        aggregator.source_config = aggregator.config.get("source", {})
        aggregator.transform_config = aggregator.config.get("transform", {})
        aggregator.target_config = aggregator.config.get("target", {})

        assert aggregator.pipeline_config == {"name": "test_gold_pipeline"}
        assert aggregator.source_config["type"] == "delta_table"
        assert aggregator.target_config["table"] == "catalog.schema.gold_tbl"
        assert aggregator.target_config["mode"] == "append"

    def test_init_has_transform_aggregations(self, patch_base_init, mock_args, gold_config):
        """Gold transform config should contain aggregation settings."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.transform_config = gold_config["transform"]

        agg = aggregator.transform_config.get("aggregations", {})
        assert agg["group_by"] == ["region"]
        assert len(agg["metrics"]) == 1
        assert agg["metrics"][0]["name"] == "total_sales"

    def test_init_sets_args(self, patch_base_init, mock_args):
        """args should be stored on the instance."""
        aggregator = GoldAggregator(mock_args)
        assert aggregator.args is mock_args


# ===================================================================
# transform()
# ===================================================================

class TestGoldTransform:
    """Tests for the GoldAggregator.transform method."""

    def test_transform_calls_executor(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """transform() should invoke TransformationExecutor.apply_transformations."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.transform_config = gold_config["transform"]

        from framework.modules.transformations.executor import TransformationExecutor
        TransformationExecutor.apply_transformations = MagicMock(return_value=mock_dataframe)

        result = aggregator.transform(mock_dataframe)

        TransformationExecutor.apply_transformations.assert_called_once()
        assert result is mock_dataframe

    def test_transform_returns_dataframe(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """transform() must return a DataFrame (not None)."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.transform_config = gold_config["transform"]

        from framework.modules.transformations.executor import TransformationExecutor
        TransformationExecutor.apply_transformations = MagicMock(return_value=mock_dataframe)

        result = aggregator.transform(mock_dataframe)
        assert result is not None

    def test_transform_includes_aggregations_step(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """Gold transformation steps should include 'aggregations'."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.transform_config = gold_config["transform"]

        from framework.modules.transformations.executor import TransformationExecutor
        TransformationExecutor.apply_transformations = MagicMock(return_value=mock_dataframe)

        aggregator.transform(mock_dataframe)

        call_args = TransformationExecutor.apply_transformations.call_args[0]
        transformation_steps = call_args[3]  # fourth arg is the steps list
        assert "aggregations" in transformation_steps

    def test_transform_passes_spark_and_config(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """apply_transformations should receive spark as the first argument."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.transform_config = gold_config["transform"]

        from framework.modules.transformations.executor import TransformationExecutor
        TransformationExecutor.apply_transformations = MagicMock(return_value=mock_dataframe)

        aggregator.transform(mock_dataframe)

        call_args = TransformationExecutor.apply_transformations.call_args[0]
        assert call_args[0] is aggregator.spark
        assert call_args[2] is aggregator.transform_config


# ===================================================================
# load()
# ===================================================================

class TestGoldLoad:
    """Tests for the GoldAggregator.load method."""

    def test_load_append_mode(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        """load() in 'append' mode should call delta_manager.write_df."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.target_config = gold_config["target"]

        aggregator.load(mock_dataframe)

        aggregator.delta_manager.write_df.assert_called_once()
        call_args = aggregator.delta_manager.write_df.call_args
        assert call_args[0][0] is mock_dataframe
        assert call_args[0][2] == "append"

    def test_load_overwrite_mode(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        """load() in 'overwrite' mode should call delta_manager.write_df."""
        aggregator = GoldAggregator(mock_args)
        gold_config["target"]["mode"] = "overwrite"
        aggregator.config = gold_config
        aggregator.target_config = gold_config["target"]

        aggregator.load(mock_dataframe)

        aggregator.delta_manager.write_df.assert_called_once()
        call_args = aggregator.delta_manager.write_df.call_args
        assert call_args[0][2] == "overwrite"

    def test_load_merge_mode(self, patch_base_init, mock_args, gold_config, mock_dataframe):
        """load() in 'merge' mode should call delta_manager.merge_df."""
        aggregator = GoldAggregator(mock_args)
        gold_config["target"]["mode"] = "merge"
        gold_config["target"]["merge_condition"] = "tgt.region = src.region"
        aggregator.config = gold_config
        aggregator.target_config = gold_config["target"]

        aggregator.load(mock_dataframe)

        aggregator.delta_manager.merge_df.assert_called_once()
        call_args = aggregator.delta_manager.merge_df.call_args
        assert call_args[0][2] == "tgt.region = src.region"

    def test_load_raises_when_no_target_table(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """load() should raise ValueError when target table is missing."""
        aggregator = GoldAggregator(mock_args)
        gold_config["target"]["table"] = None
        aggregator.config = gold_config
        aggregator.target_config = gold_config["target"]

        aggregator.env_manager.construct_table_fqn.return_value = None

        with pytest.raises(ValueError, match="No target table configured"):
            aggregator.load(mock_dataframe)

    def test_load_uses_gold_tbl_properties(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """load() should pass gold_tbl_properties to delta_manager.write_df."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.target_config = gold_config["target"]

        aggregator.load(mock_dataframe)

        call_args = aggregator.delta_manager.write_df.call_args
        assert call_args[0][3] == aggregator.delta_manager.gold_tbl_properties


# ===================================================================
# run()
# ===================================================================

class TestGoldRun:
    """Tests for the full GoldAggregator.run orchestration."""

    def test_run_happy_path(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """run() should call extract → transform → load → masker → audit."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.pipeline_config = gold_config["pipeline"]
        aggregator.source_config = gold_config["source"]
        aggregator.transform_config = gold_config["transform"]
        aggregator.target_config = gold_config["target"]

        aggregator.extract = MagicMock(return_value=mock_dataframe)
        aggregator.transform = MagicMock(return_value=mock_dataframe)
        aggregator.load = MagicMock()

        aggregator.run()

        aggregator.extract.assert_called_once()
        aggregator.transform.assert_called_once_with(mock_dataframe)
        aggregator.load.assert_called_once_with(mock_dataframe)
        aggregator.audit_logger.log_run_audit.assert_called_once()
        aggregator.audit_logger.log_run_summary.assert_called_once()

    def test_run_skips_when_extract_returns_none(
        self, patch_base_init, mock_args, gold_config
    ):
        """run() should log audit as success and return early when extract returns None."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.pipeline_config = gold_config["pipeline"]
        aggregator.source_config = gold_config["source"]
        aggregator.transform_config = gold_config["transform"]
        aggregator.target_config = gold_config["target"]

        aggregator.extract = MagicMock(return_value=None)
        aggregator.transform = MagicMock()
        aggregator.load = MagicMock()

        aggregator.run()

        aggregator.extract.assert_called_once()
        aggregator.transform.assert_not_called()
        aggregator.load.assert_not_called()
        aggregator.audit_logger.log_run_audit.assert_called_once()
        audit_call_args = aggregator.audit_logger.log_run_audit.call_args[0]
        assert "success" in audit_call_args

    def test_run_logs_error_and_reraises_on_exception(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """run() should log the error and re-raise on exception."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.pipeline_config = gold_config["pipeline"]
        aggregator.source_config = gold_config["source"]
        aggregator.transform_config = gold_config["transform"]
        aggregator.target_config = gold_config["target"]

        aggregator.extract = MagicMock(return_value=mock_dataframe)
        aggregator.transform = MagicMock(side_effect=RuntimeError("gold boom"))

        with pytest.raises(RuntimeError, match="gold boom"):
            aggregator.run()

        aggregator.audit_logger.log_error.assert_called_once()
        failure_audit_call = aggregator.audit_logger.log_run_audit.call_args[0]
        assert "failure" in failure_audit_call
        aggregator.audit_logger.log_run_summary.assert_called_once()

    def test_run_always_calls_log_run_summary(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """audit_logger.log_run_summary() is always called (in finally)."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.pipeline_config = gold_config["pipeline"]
        aggregator.source_config = gold_config["source"]
        aggregator.transform_config = gold_config["transform"]
        aggregator.target_config = gold_config["target"]

        aggregator.extract = MagicMock(side_effect=Exception("fail"))

        with pytest.raises(Exception):
            aggregator.run()

        aggregator.audit_logger.log_run_summary.assert_called_once()

    def test_run_masker_receives_correct_args(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """Masker should be instantiated with spark, args, config, env_manager."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.pipeline_config = gold_config["pipeline"]
        aggregator.source_config = gold_config["source"]
        aggregator.transform_config = gold_config["transform"]
        aggregator.target_config = gold_config["target"]

        aggregator.extract = MagicMock(return_value=mock_dataframe)
        aggregator.transform = MagicMock(return_value=mock_dataframe)
        aggregator.load = MagicMock()

        from framework.modules.security.masker import Masker
        Masker.reset_mock()

        aggregator.run()

        Masker.assert_called_once_with(
            aggregator.spark, aggregator.args, aggregator.config, aggregator.env_manager
        )

    def test_run_audit_logged_as_success(
        self, patch_base_init, mock_args, gold_config, mock_dataframe
    ):
        """On a successful run, audit should be logged with 'success' event."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.pipeline_config = gold_config["pipeline"]
        aggregator.source_config = gold_config["source"]
        aggregator.transform_config = gold_config["transform"]
        aggregator.target_config = gold_config["target"]

        aggregator.extract = MagicMock(return_value=mock_dataframe)
        aggregator.transform = MagicMock(return_value=mock_dataframe)
        aggregator.load = MagicMock()

        aggregator.run()

        success_audit_call = aggregator.audit_logger.log_run_audit.call_args[0]
        assert "success" in success_audit_call

    def test_run_no_masker_when_extract_returns_none(
        self, patch_base_init, mock_args, gold_config
    ):
        """When extract returns None, Masker should NOT be called."""
        aggregator = GoldAggregator(mock_args)
        aggregator.config = gold_config
        aggregator.pipeline_config = gold_config["pipeline"]
        aggregator.source_config = gold_config["source"]
        aggregator.transform_config = gold_config["transform"]
        aggregator.target_config = gold_config["target"]

        aggregator.extract = MagicMock(return_value=None)
        aggregator.transform = MagicMock()
        aggregator.load = MagicMock()

        from framework.modules.security.masker import Masker
        Masker.reset_mock()

        aggregator.run()

        Masker.return_value.apply_masking.assert_not_called()
