"""
Unit tests for framework.layers.silver.silver_refiner.SilverRefiner

Uses patch_base_init fixture from conftest.py — all Spark/Databricks
dependencies are mocked via sys.modules patching.

NOTE: Written against the zip-packaged source which uses:
  - TransformationExecutor.apply_transformations()
  - Config keys: 'pipeline', 'target'
  - log_run_audit(df, config, event_type, start_dtm)
"""

import pytest
from unittest.mock import MagicMock

from framework.layers.silver.silver_refiner import SilverRefiner


# ===================================================================
# Construction / Initialisation
# ===================================================================

class TestSilverRefinerInit:
    """Tests for __init__ and attribute setup."""

    def test_init_loads_config_sections(self, patch_base_init, mock_args, silver_config):
        """pipeline, source, transform, target configs are loaded."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = refiner.config.get("pipeline", {})
        refiner.source_config = refiner.config.get("source", {})
        refiner.transform_config = refiner.config.get("transform", {})
        refiner.target_config = refiner.config.get("target", {})

        assert refiner.pipeline_config == {"name": "test_silver_pipeline"}
        assert refiner.source_config["type"] == "delta_table"
        assert refiner.target_config["mode"] == "overwrite"

    def test_init_sets_args(self, patch_base_init, mock_args):
        """args should be stored on the instance."""
        refiner = SilverRefiner(mock_args)
        assert refiner.args is mock_args

    def test_init_does_not_have_files_discovered(self, patch_base_init, mock_args):
        """SilverRefiner does not add to files_discovered (unlike Bronze)."""
        refiner = SilverRefiner(mock_args)
        assert refiner.files_discovered == []


# ===================================================================
# transform()
# ===================================================================

class TestSilverTransform:
    """Tests for the SilverRefiner.transform method."""

    def test_transform_calls_executor(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """transform() should invoke TransformationExecutor.apply_transformations."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.transform_config = silver_config["transform"]

        from framework.modules.transformations.executor import TransformationExecutor
        TransformationExecutor.apply_transformations = MagicMock(return_value=mock_dataframe)

        result = refiner.transform(mock_dataframe)

        TransformationExecutor.apply_transformations.assert_called_once()
        assert result is mock_dataframe

    def test_transform_returns_dataframe(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """transform() must return a DataFrame (not None)."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.transform_config = silver_config["transform"]

        from framework.modules.transformations.executor import TransformationExecutor
        TransformationExecutor.apply_transformations = MagicMock(return_value=mock_dataframe)

        result = refiner.transform(mock_dataframe)
        assert result is not None

    def test_transform_passes_spark_and_config(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """apply_transformations should receive spark, df, config, and steps."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.transform_config = silver_config["transform"]

        from framework.modules.transformations.executor import TransformationExecutor
        TransformationExecutor.apply_transformations = MagicMock(return_value=mock_dataframe)

        refiner.transform(mock_dataframe)

        call_args = TransformationExecutor.apply_transformations.call_args[0]
        assert call_args[0] is refiner.spark
        assert call_args[2] is refiner.transform_config


# ===================================================================
# load()
# ===================================================================

class TestSilverLoad:
    """Tests for the SilverRefiner.load method."""

    def test_load_overwrite_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        """load() in 'overwrite' mode should call delta_manager.write_df."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]

        refiner.load(mock_dataframe)

        refiner.delta_manager.write_df.assert_called_once()
        call_args = refiner.delta_manager.write_df.call_args
        assert call_args[0][0] is mock_dataframe
        assert call_args[0][2] == "overwrite"

    def test_load_append_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        """load() in 'append' mode should call delta_manager.write_df."""
        refiner = SilverRefiner(mock_args)
        silver_config["target"]["mode"] = "append"
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]

        refiner.load(mock_dataframe)

        refiner.delta_manager.write_df.assert_called_once()
        call_args = refiner.delta_manager.write_df.call_args
        assert call_args[0][2] == "append"

    def test_load_merge_mode(self, patch_base_init, mock_args, silver_config, mock_dataframe):
        """load() in 'merge' mode should call delta_manager.merge_df."""
        refiner = SilverRefiner(mock_args)
        silver_config["target"]["mode"] = "merge"
        silver_config["target"]["merge_condition"] = "tgt.id = src.id"
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]

        refiner.load(mock_dataframe)

        refiner.delta_manager.merge_df.assert_called_once()
        call_args = refiner.delta_manager.merge_df.call_args
        assert call_args[0][2] == "tgt.id = src.id"

    def test_load_raises_when_no_target_table(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """load() should raise ValueError when target table is missing."""
        refiner = SilverRefiner(mock_args)
        silver_config["target"]["table"] = None
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]

        refiner.env_manager.construct_table_fqn.return_value = None

        with pytest.raises(ValueError, match="No target table configured"):
            refiner.load(mock_dataframe)

    def test_load_uses_silver_tbl_properties(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """load() should pass silver_tbl_properties to delta_manager.write_df."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.target_config = silver_config["target"]

        refiner.load(mock_dataframe)

        call_args = refiner.delta_manager.write_df.call_args
        assert call_args[0][3] == refiner.delta_manager.silver_tbl_properties


# ===================================================================
# run()
# ===================================================================

class TestSilverRun:
    """Tests for the full SilverRefiner.run orchestration."""

    def test_run_happy_path(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """run() should call extract → transform → DQ → load → masker → audit."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]

        refiner.extract = MagicMock(return_value=mock_dataframe)
        refiner.transform = MagicMock(return_value=mock_dataframe)
        refiner.load = MagicMock()

        from framework.modules.dq.dqx_validator import DataQualityCheck
        dq_instance = MagicMock()
        dq_instance.apply_checks.return_value = mock_dataframe
        DataQualityCheck.return_value = dq_instance

        refiner.run()

        refiner.extract.assert_called_once()
        refiner.transform.assert_called_once_with(mock_dataframe)
        dq_instance.apply_checks.assert_called_once_with(mock_dataframe)
        refiner.load.assert_called_once_with(mock_dataframe)
        refiner.audit_logger.log_run_audit.assert_called_once()
        refiner.audit_logger.log_run_summary.assert_called_once()

    def test_run_skips_when_extract_returns_none(
        self, patch_base_init, mock_args, silver_config
    ):
        """run() should log audit as success and return early when extract returns None."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]

        refiner.extract = MagicMock(return_value=None)
        refiner.transform = MagicMock()
        refiner.load = MagicMock()

        refiner.run()

        refiner.extract.assert_called_once()
        refiner.transform.assert_not_called()
        refiner.load.assert_not_called()
        # Audit logged as success even for null extract
        refiner.audit_logger.log_run_audit.assert_called_once()
        audit_call_args = refiner.audit_logger.log_run_audit.call_args[0]
        assert "success" in audit_call_args

    def test_run_logs_error_and_reraises_on_exception(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """run() should log the error and re-raise on exception."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]

        refiner.extract = MagicMock(return_value=mock_dataframe)
        refiner.transform = MagicMock(side_effect=RuntimeError("silver boom"))

        with pytest.raises(RuntimeError, match="silver boom"):
            refiner.run()

        refiner.audit_logger.log_error.assert_called_once()
        failure_audit_call = refiner.audit_logger.log_run_audit.call_args[0]
        assert "failure" in failure_audit_call
        refiner.audit_logger.log_run_summary.assert_called_once()

    def test_run_always_calls_log_run_summary(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """audit_logger.log_run_summary() is always called (in finally)."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]

        refiner.extract = MagicMock(side_effect=Exception("fail"))

        with pytest.raises(Exception):
            refiner.run()

        refiner.audit_logger.log_run_summary.assert_called_once()

    def test_run_invokes_data_quality_check(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """DQ checks should be applied between transform and load."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]

        refiner.extract = MagicMock(return_value=mock_dataframe)
        refiner.transform = MagicMock(return_value=mock_dataframe)
        refiner.load = MagicMock()

        from framework.modules.dq.dqx_validator import DataQualityCheck
        dq_instance = MagicMock()
        dq_instance.apply_checks.return_value = mock_dataframe
        DataQualityCheck.return_value = dq_instance

        refiner.run()

        DataQualityCheck.assert_called_with(
            refiner.spark, refiner.config, refiner.env_manager,
            refiner.audit_logger, refiner.delta_manager
        )
        dq_instance.apply_checks.assert_called_once_with(mock_dataframe)

    def test_run_passes_dq_result_to_load(
        self, patch_base_init, mock_args, silver_config, mock_dataframe
    ):
        """The DataFrame returned by DQ checks should be the one passed to load()."""
        refiner = SilverRefiner(mock_args)
        refiner.config = silver_config
        refiner.pipeline_config = silver_config["pipeline"]
        refiner.source_config = silver_config["source"]
        refiner.transform_config = silver_config["transform"]
        refiner.target_config = silver_config["target"]

        dq_output_df = MagicMock(name="DQ_Output_DF")

        refiner.extract = MagicMock(return_value=mock_dataframe)
        refiner.transform = MagicMock(return_value=mock_dataframe)
        refiner.load = MagicMock()

        from framework.modules.dq.dqx_validator import DataQualityCheck
        dq_instance = MagicMock()
        dq_instance.apply_checks.return_value = dq_output_df
        DataQualityCheck.return_value = dq_instance

        refiner.run()

        refiner.load.assert_called_once_with(dq_output_df)
