# setup.py
# Removal of this file was throwing the error in CICD pipeline
# So setup() is kept empty intentionally here as it was required by CICD pipeline

from setuptools import setup, find_packages

setup()